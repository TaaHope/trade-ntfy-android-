"""Trade ntfy general notification API. Deploy behind HTTPS; never expose the service-account key."""
import os
import re
import sqlite3
import time
from pathlib import Path
from functools import wraps

import firebase_admin
from firebase_admin import auth, credentials, messaging
from flask import Flask, g, jsonify, request

app = Flask(__name__)
DB_PATH = os.environ.get("TRADE_NTFY_DB", str(Path(__file__).with_name("trade_ntfy.db")))
PROJECT_ID = os.environ.get("FCM_PROJECT_ID", "").strip()
SERVICE_ACCOUNT = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "").strip()


def firebase_app():
    try:
        return firebase_admin.get_app()
    except ValueError:
        if not PROJECT_ID or not SERVICE_ACCOUNT or not os.path.isfile(SERVICE_ACCOUNT):
            raise RuntimeError("Set FCM_PROJECT_ID and GOOGLE_APPLICATION_CREDENTIALS on the server.")
        return firebase_admin.initialize_app(credentials.Certificate(SERVICE_ACCOUNT), {"projectId": PROJECT_ID})


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS devices (
          uid TEXT NOT NULL, token TEXT NOT NULL UNIQUE, device_name TEXT NOT NULL DEFAULT '',
          updated_at INTEGER NOT NULL, PRIMARY KEY(uid, token)
        );
        CREATE TABLE IF NOT EXISTS topics (
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
          owner_uid TEXT NOT NULL, created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS subscriptions (
          uid TEXT NOT NULL, topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
          created_at INTEGER NOT NULL, PRIMARY KEY(uid, topic_id)
        );
        CREATE TABLE IF NOT EXISTS send_log (
          uid TEXT NOT NULL, sent_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sub_topic ON subscriptions(topic_id);
        CREATE INDEX IF NOT EXISTS idx_devices_uid ON devices(uid);
        CREATE INDEX IF NOT EXISTS idx_send_log_uid_time ON send_log(uid, sent_at);
        """)


init_db()


def require_user(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return jsonify(error="Sign-in required."), 401
        try:
            decoded = auth.verify_id_token(header[7:].strip(), app=firebase_app(), check_revoked=True)
            g.uid = decoded["uid"]
        except Exception:
            return jsonify(error="Invalid or expired sign-in token."), 401
        return fn(*args, **kwargs)
    return wrapper


def clean_topic(value):
    name = re.sub(r"\s+", "-", str(value or "").strip().lower())
    if not 2 <= len(name) <= 80 or not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", name):
        raise ValueError("Topic must be 2–80 characters using letters, numbers, dots, underscores or hyphens.")
    return name


@app.get("/api/health")
def health():
    return jsonify(ok=True, service="trade-ntfy-api")


@app.post("/api/device")
@require_user
def register_device():
    payload = request.get_json(silent=True) or {}
    token = str(payload.get("token", "")).strip()
    device_name = str(payload.get("device_name", ""))[:120]
    if not token or len(token) > 4096:
        return jsonify(error="A valid FCM device token is required."), 400
    now = int(time.time())
    conn = db()
    conn.execute("DELETE FROM devices WHERE token=? AND uid<>?", (token, g.uid))
    conn.execute("INSERT INTO devices(uid,token,device_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(uid,token) DO UPDATE SET device_name=excluded.device_name, updated_at=excluded.updated_at", (g.uid, token, device_name, now))
    conn.commit()
    return jsonify(ok=True, message="Device registered.")


@app.get("/api/topics")
@require_user
def list_topics():
    rows = db().execute("SELECT t.name,t.owner_uid FROM topics t JOIN subscriptions s ON s.topic_id=t.id WHERE s.uid=? ORDER BY t.name", (g.uid,)).fetchall()
    return jsonify(topics=[{"name": r["name"], "owner": r["owner_uid"] == g.uid} for r in rows])


@app.post("/api/topics/create")
@require_user
def create_topic():
    payload = request.get_json(silent=True) or {}
    try:
        name = clean_topic(payload.get("name"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    conn = db()
    try:
        cur = conn.execute("INSERT INTO topics(name,owner_uid,created_at) VALUES(?,?,?)", (name, g.uid, int(time.time())))
        topic_id = cur.lastrowid
    except sqlite3.IntegrityError:
        row = conn.execute("SELECT id,owner_uid FROM topics WHERE name=?", (name,)).fetchone()
        if not row or row["owner_uid"] != g.uid:
            return jsonify(error="That topic already exists. Join it by its exact name if you have permission."), 409
        topic_id = row["id"]
    conn.execute("INSERT OR IGNORE INTO subscriptions(uid,topic_id,created_at) VALUES(?,?,?)", (g.uid, topic_id, int(time.time())))
    conn.commit()
    return jsonify(ok=True, message=f"Topic '{name}' created and joined.", topic=name)


@app.post("/api/topics/join")
@require_user
def join_topic():
    payload = request.get_json(silent=True) or {}
    try:
        name = clean_topic(payload.get("name"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    conn = db()
    row = conn.execute("SELECT id FROM topics WHERE name=?", (name,)).fetchone()
    if not row:
        return jsonify(error="Topic not found. Ask its owner to create it first."), 404
    conn.execute("INSERT OR IGNORE INTO subscriptions(uid,topic_id,created_at) VALUES(?,?,?)", (g.uid, row["id"], int(time.time())))
    conn.commit()
    return jsonify(ok=True, message=f"Joined topic '{name}'.", topic=name)


@app.post("/api/topics/leave")
@require_user
def leave_topic():
    payload = request.get_json(silent=True) or {}
    try:
        name = clean_topic(payload.get("name"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    conn = db()
    row = conn.execute("SELECT id,owner_uid FROM topics WHERE name=?", (name,)).fetchone()
    if not row:
        return jsonify(error="Topic not found."), 404
    if row["owner_uid"] == g.uid:
        return jsonify(error="Topic owner cannot leave their own topic. Delete it through the admin process."), 403
    conn.execute("DELETE FROM subscriptions WHERE uid=? AND topic_id=?", (g.uid, row["id"]))
    conn.commit()
    return jsonify(ok=True, message=f"Left topic '{name}'.")


@app.post("/api/notifications/send")
@require_user
def send_notification():
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("title", "")).strip()
    body = str(payload.get("body", "")).strip()
    try:
        topic = clean_topic(payload.get("topic"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    if not title or not body:
        return jsonify(error="Title and message are required."), 400
    if len(title) > 120 or len(body) > 3000:
        return jsonify(error="Title limit is 120 characters; message limit is 3,000 characters."), 400
    conn = db()
    topic_row = conn.execute("SELECT id FROM topics WHERE name=?", (topic,)).fetchone()
    if not topic_row:
        return jsonify(error="Topic not found. Create or join a topic first."), 404
    member = conn.execute("SELECT 1 FROM subscriptions WHERE uid=? AND topic_id=?", (g.uid, topic_row["id"])).fetchone()
    if not member:
        return jsonify(error="You must subscribe to this topic before sending to it."), 403
    now = int(time.time())
    tokens = [r[0] for r in conn.execute("SELECT DISTINCT d.token FROM devices d JOIN subscriptions s ON s.uid=d.uid WHERE s.topic_id=?", (topic_row["id"],)).fetchall()]
    conn.commit()
    if not tokens:
        return jsonify(ok=True, message="Notification accepted; no subscribed devices are registered yet.", delivered=0)
    sent = 0
    failed = 0
    firebase = firebase_app()
    for start in range(0, len(tokens), 500):
        batch = tokens[start:start + 500]
        # Data-only delivery lets the Android service save the message to the in-app inbox
        # and display the notification whether the app is foregrounded or backgrounded.
        message = messaging.MulticastMessage(
            data={"title": title, "body": body, "topic": topic},
            android=messaging.AndroidConfig(priority="high"),
            tokens=batch,
        )
        response = messaging.send_each_for_multicast(message, app=firebase)
        sent += response.success_count
        failed += response.failure_count
        for index, result in enumerate(response.responses):
            if not result.success and result.exception and "registration-token-not-registered" in str(result.exception).lower():
                conn.execute("DELETE FROM devices WHERE token=?", (batch[index],))
    conn.commit()
    return jsonify(ok=True, message=f"Notification sent to topic '{topic}'.", delivered=sent, failed=failed)


if __name__ == "__main__":
    # Local development only. For public deployment use a production WSGI server and HTTPS reverse proxy.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8766")), debug=False)
