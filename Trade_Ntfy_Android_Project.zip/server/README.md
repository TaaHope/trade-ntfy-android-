# Trade ntfy notification API

Separate Flask API for Firebase-authenticated device registration, topics, subscriptions and sending general notifications through Firebase Cloud Messaging.

See `../README_PHONE_SETUP.md` for deployment and security instructions. Deploy behind HTTPS using a production WSGI server; never commit the Firebase Admin service-account JSON.
