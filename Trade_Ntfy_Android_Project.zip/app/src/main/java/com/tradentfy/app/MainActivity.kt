package com.tradentfy.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var selectedPage = "Inbox"

    companion object { lateinit var appContext: Context }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appContext = applicationContext
        createNotificationChannel()
        requestNotificationPermission()
        showCurrentScreen()
    }

    override fun onResume() { super.onResume(); if (auth.currentUser != null) registerToken() }

    private fun showCurrentScreen() {
        if (auth.currentUser == null) showAuthScreen() else showMainScreen(selectedPage)
    }

    private fun baseRoot(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
            setPadding(dp(18), dp(20), dp(18), dp(12))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(12)) }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher); scaleType = android.widget.ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(12) })
        brandRow.addView(TextView(this).apply { text = "Trade ntfy"; textSize = 29f; setTextColor(Color.rgb(17, 63, 139)); setTypeface(null, android.graphics.Typeface.BOLD) })
        header.addView(brandRow)
        header.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(Color.rgb(93, 105, 125)); setPadding(0, dp(8), 0, 0) })
        root.addView(header)
        status = TextView(this).apply { textSize = 13f; setTextColor(Color.rgb(44, 104, 88)); setPadding(0, dp(4), 0, dp(6)) }
        root.addView(status)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return root
    }

    private fun showAuthScreen() {
        baseRoot("General notifications for apps, teams and services")
        val email = edit("Email address", "textEmailAddress")
        val password = edit("Password", "textPassword")
        val signIn = button("Sign in") {
            if (email.text.isBlank() || password.text.isBlank()) { toast("Enter email and password."); return@button }
            busy("Signing in…") {
                auth.signInWithEmailAndPassword(email.text.toString().trim(), password.text.toString()).addOnCompleteListener { task ->
                    if (task.isSuccessful) { registerToken(); showMainScreen("Inbox") } else status.text = task.exception?.localizedMessage ?: "Sign-in failed."
                }
            }
        }
        content.addView(card("Sign in to Trade ntfy", "Create an account to send and receive notifications across your devices."))
        content.addView(email); content.addView(password); content.addView(signIn)
        content.addView(button("Create account") {
            if (email.text.isBlank() || password.text.length < 6) { toast("Enter an email and a password of at least 6 characters."); return@button }
            auth.createUserWithEmailAndPassword(email.text.toString().trim(), password.text.toString()).addOnCompleteListener { task ->
                if (task.isSuccessful) { registerToken(); showMainScreen("Inbox") } else status.text = task.exception?.localizedMessage ?: "Account creation failed."
            }
        })
        content.addView(TextView(this).apply {
            text = "First setup: enter your deployed HTTPS notification-server URL under Settings after signing in. The server URL is not preconfigured in this app."
            textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, dp(18), 0, 0)
        })
    }

    private fun showMainScreen(page: String) {
        selectedPage = page
        baseRoot(when (page) {
            "Send" -> "Compose and publish a notification"
            "Topics" -> "Create topics and manage subscriptions"
            "Settings" -> "Account and connection settings"
            else -> "Your notification inbox"
        })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
        listOf("Inbox", "Send", "Topics", "Settings").forEach { item ->
            val b = Button(this).apply { text = item; textSize = 11f; isAllCaps = false; setOnClickListener { showMainScreen(item) } }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(3) })
        }
        root.addView(nav, 1)
        when (page) {
            "Send" -> showSend()
            "Topics" -> showTopics()
            "Settings" -> showSettings()
            else -> showInbox()
        }
    }

    private fun showInbox() {
        content.addView(button("Refresh inbox") { showMainScreen("Inbox") })
        val prefs = getSharedPreferences("trade_ntfy_inbox", 0)
        val array = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        if (array.length() == 0) content.addView(card("No notifications yet", "Notifications received by this device will appear here and in Android notifications."))
        for (i in array.length() - 1 downTo 0) {
            val item = array.optJSONObject(i) ?: continue
            content.addView(card(item.optString("title", "Notification"), item.optString("body", "") + "\n\n" + item.optString("time", "")))
        }
        content.addView(button("Clear inbox") { prefs.edit().putString("items", "[]").apply(); showMainScreen("Inbox") })
    }

    private fun showSend() {
        val title = edit("Notification title", "textCapSentences")
        val body = multilineEdit("Message")
        val topic = edit("Topic name (for example: team-updates)", "text")
        content.addView(title); content.addView(body); content.addView(topic)
        content.addView(button("Send notification") {
            if (title.text.isBlank() || body.text.isBlank() || topic.text.isBlank()) { toast("Enter a title, message and topic."); return@button }
            val payload = JSONObject().put("title", title.text.toString().trim()).put("body", body.text.toString().trim()).put("topic", topic.text.toString().trim())
            runApi("/api/notifications/send", payload, "Notification sent.")
        })
        content.addView(card("How sending works", "You can send to a topic only after the backend is deployed and your account is subscribed to that topic. The server checks account access before delivery."))
    }

    private fun showTopics() {
        val name = edit("Topic name", "text")
        content.addView(name)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Create topic") {
            if (name.text.isBlank()) { toast("Enter a topic name."); return@button }
            runApi("/api/topics/create", JSONObject().put("name", name.text.toString().trim()), "Topic created and joined.") { showMainScreen("Topics") }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("Join topic") {
            if (name.text.isBlank()) { toast("Enter a topic name."); return@button }
            runApi("/api/topics/join", JSONObject().put("name", name.text.toString().trim()), "Topic joined.") { showMainScreen("Topics") }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(actions)
        content.addView(button("Load my topics") {
            busy("Loading topics…") {
                try {
                    val result = ApiClient.request("GET", "/api/topics")
                    runOnUiThread {
                        val topics = ApiClient.parseTopics(result)
                        if (topics.length() == 0) content.addView(card("No topics yet", "Create a topic or join one by its exact name."))
                        for (i in 0 until topics.length()) {
                            val t = topics.getJSONObject(i)
                            content.addView(card(t.optString("name"), if (t.optBoolean("owner")) "Created by you" else "Subscribed"))
                        }
                        status.text = "Loaded ${topics.length()} topic(s)."
                    }
                } catch (e: Exception) { runOnUiThread { status.text = e.message ?: "Could not load topics." } }
            }
        })
        content.addView(card("Topics", "Topic names are case-insensitive. Notifications are delivered to devices registered by subscribed accounts."))
    }

    private fun showSettings() {
        val url = edit("Backend HTTPS URL", "textUri")
        url.setText(ApiClient.baseUrl())
        content.addView(card("Server connection", "The backend must be deployed with HTTPS. Do not enter your Firebase service-account key or any private API secret in this app."))
        content.addView(url)
        content.addView(button("Save server URL") {
            val value = url.text.toString().trim().trimEnd('/')
            if (!value.startsWith("https://")) { toast("Use an HTTPS URL, for example https://notify.example.com"); return@button }
            ApiClient.saveBaseUrl(value)
            status.text = "Server URL saved. Registering this device…"
            registerToken()
        })
        content.addView(button("Test connection") {
            busy("Testing connection…") {
                try {
                    val result = ApiClient.request("GET", "/api/health")
                    runOnUiThread { status.text = if (result.optBoolean("ok")) "Backend connection successful." else "Backend responded." }
                } catch (e: Exception) { runOnUiThread { status.text = e.message ?: "Connection failed." } }
            }
        })
        content.addView(button("Copy device token") {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("FCM token", token)); toast("Device token copied. Keep it private.")
            }
        })
        content.addView(button("Sign out") { auth.signOut(); showAuthScreen() })
    }

    private fun registerToken() {
        if (auth.currentUser == null || ApiClient.baseUrl().isBlank()) return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            executor.execute {
                try { ApiClient.registerDevice(token); runOnUiThread { if (selectedPage == "Settings") status.text = "Device registered with notification server." } }
                catch (e: Exception) { runOnUiThread { if (selectedPage == "Settings") status.text = e.message ?: "Device registration failed." } }
            }
        }
    }

    private fun runApi(path: String, payload: JSONObject, successMessage: String, after: (() -> Unit)? = null) {
        busy("Sending request…") {
            try {
                val result = ApiClient.request("POST", path, payload)
                runOnUiThread { status.text = result.optString("message", successMessage); toast(status.text.toString()); after?.invoke() }
            } catch (e: Exception) { runOnUiThread { status.text = e.message ?: "Request failed." } }
        }
    }

    private fun busy(message: String, work: () -> Unit) { status.text = message; executor.execute(work) }
    private fun edit(hintText: String, type: String): EditText = EditText(this).apply {
        hint = hintText; textSize = 15f; isSingleLine = true
        inputType = when (type) { "textEmailAddress" -> android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; "textPassword" -> android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; "textUri" -> android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI; else -> android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }
    private fun multilineEdit(hintText: String): EditText = edit(hintText, "text").apply { isSingleLine = false; minLines = 3; gravity = Gravity.TOP; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
    }
    private fun card(title: String, body: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); setBackgroundColor(Color.WHITE)
        addView(TextView(this@MainActivity).apply { text = title; textSize = 17f; setTextColor(Color.rgb(24, 49, 91)); setTypeface(null, android.graphics.Typeface.BOLD) })
        addView(TextView(this@MainActivity).apply { text = body; textSize = 14f; setTextColor(Color.rgb(88, 98, 115)); setPadding(0, dp(6), 0, 0) })
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("trade_ntfy_general", "Trade ntfy notifications", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "General notifications from subscribed topics"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
