package com.tradentfy.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var currentScreen = "topics"
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val server: String get() = prefs.getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')
    private val blue = Color.rgb(48, 91, 222)
    private val navy = Color.rgb(18, 35, 82)
    private val pale = Color.rgb(235, 249, 239) // light green canvas; blue header remains unchanged

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        showTopics(); startSubscriber()
    }
    override fun onResume() { super.onResume(); if (currentScreen == "topics" && ::list.isInitialized) showTopics() }

    private fun topics(): MutableList<String> {
        val arr = try { JSONArray(prefs.getString("topics", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }.distinct().toMutableList()
    }
    private fun saveTopics(items: List<String>) { prefs.edit().putString("topics", JSONArray(items.distinct()).toString()).apply(); startSubscriber() }

    private fun baseScreen(title: String, subtitle: String? = null): LinearLayout {
        currentScreen = if (title == "Settings") "settings" else "topics"
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (prefs.getBoolean("dark_mode", false)) Color.rgb(20, 24, 35) else pale) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(13), dp(10), dp(13)); setBackgroundColor(blue) }
        if (title != "Subscribed topics") bar.addView(TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(Color.WHITE); setPadding(0,0,dp(18),0); setOnClickListener { showTopics() } })
        bar.addView(TextView(this).apply { text = title; textSize = 23f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        if (title == "Subscribed topics") bar.addView(TextView(this).apply { text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12),0,dp(12),0); setOnClickListener { showOverflow(this) } })
        root.addView(bar)
        if (subtitle != null) root.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(dp(16),dp(6),dp(16),dp(6)) })
        setContentView(root)
        return root
    }

    private fun showTopics() {
        currentScreen = "topics"
        baseScreen("Subscribed topics", "Server: $server")
        val scroll = ScrollView(this); list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (prefs.getBoolean("dark_mode", false)) Color.rgb(20,24,35) else pale) }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val all = topics()
        if (all.isEmpty()) list.addView(TextView(this).apply { text = "No subscriptions yet.\n\nTap + to add a topic."; textSize = 17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); gravity = Gravity.CENTER; setPadding(dp(28),dp(65),dp(28),dp(65)) })
        else all.forEach { topic ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(17),dp(14),dp(17)); setBackgroundColor(Color.WHITE); setOnClickListener { showTopic(topic) } }
            row.addView(TextView(this).apply { text = "▣"; textSize = 29f; setTextColor(blue); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(48),dp(50)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
            texts.addView(TextView(this).apply { text = topic; textSize = 17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.WHITE else navy) })
            texts.addView(TextView(this).apply { text = "${prefs.getInt("count_$topic",0)} notifications"; textSize = 14f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); setPadding(0,dp(3),0,0) })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f)); row.addView(TextView(this).apply { text="›"; textSize=28f; setTextColor(Color.GRAY) })
            list.addView(row); list.addView(View(this).apply { setBackgroundColor(Color.rgb(230,234,244)) },LinearLayout.LayoutParams(-1,dp(1)))
        }
        val fab = TextView(this).apply { text="+"; textSize=36f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(blue); elevation=dp(5).toFloat(); setOnClickListener { showAddTopicDialog() } }
        val fabRow = LinearLayout(this).apply { gravity=Gravity.RIGHT; setPadding(dp(14),dp(8),dp(20),dp(20)); addView(fab,LinearLayout.LayoutParams(dp(64),dp(64))) }
        root.addView(fabRow)
    }

    private fun showOverflow(anchor: View) {
        PopupMenu(this,anchor).apply {
            menu.add("Settings").setOnMenuItemClickListener { showSettings(); true }
            menu.add("Send notification").setOnMenuItemClickListener { val ts=topics(); if(ts.isEmpty()) showAddTopicDialog() else showPublishDialog(ts.first()); true }
            menu.add("Clear notification history").setOnMenuItemClickListener { confirmClearHistory(); true }
            menu.add("Share Trade ntfy").setOnMenuItemClickListener { shareApp(); true }
            menu.add("About").setOnMenuItemClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Trade ntfy").setMessage("General-purpose topic notifications. Supports ntfy-compatible servers.\n\nVersion 1.3").setPositiveButton("OK",null).show(); true }
            show()
        }
    }

    private fun showAddTopicDialog() {
        val topicInput=EditText(this).apply { hint="Topic name (e.g. team-updates)"; setSingleLine(true) }
        val serverInput=EditText(this).apply { hint="Server URL"; setSingleLine(true); setText(server); inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(22),dp(8),dp(22),0); addView(TextView(this@MainActivity).apply { text="Server URL" }); addView(serverInput); addView(TextView(this@MainActivity).apply { text="Topic name"; setPadding(0,dp(8),0,0) }); addView(topicInput) }
        AlertDialog.Builder(this).setTitle("Add subscription").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Subscribe") { _,_ ->
            val topic=topicInput.text.toString().trim(); val candidate=serverInput.text.toString().trim().trimEnd('/')
            if(!validTopic(topic)) { toast("Use 1–64 letters, numbers, dots, hyphens or underscores."); return@setPositiveButton }
            if(!candidate.startsWith("https://")) { toast("Enter a valid HTTPS server URL."); return@setPositiveButton }
            prefs.edit().putString("server",candidate).apply(); val items=topics(); if(topic !in items) items.add(topic); saveTopics(items); showTopics(); toast("Subscribed to $topic")
        }.show()
    }

    private fun showSettings() {
        currentScreen="settings"; baseScreen("Settings")
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(22)) }; scroll.addView(content); root.addView(scroll)
        section(content,"General")
        settingRow(content,"Default server","Server used when adding a subscription · $server") { editTextDialog("Default server URL",server,"https://ntfy.sh") { v -> if(!v.startsWith("https://")) toast("Use an HTTPS URL.") else { prefs.edit().putString("server",v.trim().trimEnd('/')).apply(); startSubscriber(); showSettings() } } }
        settingRow(content,"Account / authentication","Optional username and password for protected topics") { showCredentialsDialog() }
        section(content,"Notifications")
        settingRow(content,"Notification alerts",if(prefs.getBoolean("alerts",true)) "Enabled · Android notifications shown" else "Disabled") { toggleSetting("alerts","Notification alerts") }
        settingRow(content,"Minimum priority", "Current: ${prefs.getInt("min_priority",1)} · Tap to change") { choose("Minimum priority",arrayOf("Min (1)","Low (2)","Default (3)","High (4)","Urgent (5)"),prefs.getInt("min_priority",1)-1) { prefs.edit().putInt("min_priority",it+1).apply(); showSettings() } }
        settingRow(content,"Mute notifications",if(prefs.getBoolean("muted",false)) "Muted" else "Showing all notifications") { toggleSetting("muted","Mute notifications") }
        settingRow(content,"Keep alerting for highest priority",if(prefs.getBoolean("repeat_urgent",false)) "Enabled" else "Disabled") { toggleSetting("repeat_urgent","Keep alerting for highest priority") }
        settingRow(content,"Channel settings","Android sound, vibration and Do Not Disturb settings") { if(Build.VERSION.SDK_INT>=26) { val i=Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,packageName).putExtra(android.provider.Settings.EXTRA_CHANNEL_ID,"trade_ntfy_messages"); startActivity(i) } else toast("Manage notification sound in Android settings.") }
        settingRow(content,"Delete notifications","Auto-delete after ${prefs.getInt("retention_days",30)} days") { choose("Delete notifications",arrayOf("Never","7 days","30 days","90 days"),when(prefs.getInt("retention_days",30)){0->0;7->1;30->2;90->3;else->2}) { val days=listOf(0,7,30,90)[it]; prefs.edit().putInt("retention_days",days).apply(); pruneHistory(); showSettings() } }
        section(content,"Appearance")
        settingRow(content,"Dark mode",if(prefs.getBoolean("dark_mode",false)) "Enabled" else "Disabled") { toggleSetting("dark_mode","Dark mode"); showSettings() }
        settingRow(content,"Show message bar",if(prefs.getBoolean("message_bar",true)) "Shown at bottom of topic view" else "Hidden") { toggleSetting("message_bar","Show message bar") }
        section(content,"Backup & Restore")
        settingRow(content,"Back up to file","Export subscriptions and settings to a JSON file") { createBackupFile() }
        settingRow(content,"Restore from file","Import subscriptions and settings from a JSON file") { openBackupFile() }
        section(content,"Advanced")
        settingRow(content,"Connection protocol",if(prefs.getBoolean("json_stream",true)) "Long-lived JSON stream (recommended)" else "Short-timeout JSON stream (reconnects more often)") { choose("Connection protocol",arrayOf("Long-lived JSON stream","Short-timeout JSON stream"),if(prefs.getBoolean("json_stream",true))0 else 1) { prefs.edit().putBoolean("json_stream",it==0).apply(); startSubscriber(); showSettings() } }
        settingRow(content,"Custom headers","Configure HTTP headers for authenticated servers") { showHeadersDialog() }
        settingRow(content,"Manage certificates","Use Android's certificate settings for trusted certificates") { try { startActivity(Intent("android.settings.SECURITY_SETTINGS")) } catch (_:Exception) { toast("Open Android Settings → Security to manage certificates.") } }
        settingRow(content,"Record logs",if(prefs.getBoolean("record_logs",false)) "Enabled · Tap to view saved diagnostics" else "Disabled · Save connection and message events") { if(prefs.getBoolean("record_logs",false)) showLogsDialog() else { prefs.edit().putBoolean("record_logs",true).apply(); toast("Diagnostic logging enabled."); showSettings() } }
        settingRow(content,"Manage subscriptions","View or remove saved topics") { manageSubscriptions() }
        settingRow(content,"Clear notification history","Delete all locally saved notifications") { confirmClearHistory() }
        settingRow(content,"Test connection","Check whether the selected server is reachable") { testConnection(server) }
        settingRow(content,"Share Trade ntfy","Share the app link") { shareApp() }
        section(content,"About")
        settingRow(content,"Version","Trade ntfy 1.4") { AlertDialog.Builder(this).setTitle("Trade ntfy").setMessage("General-purpose notifications for apps, teams and services.").setPositiveButton("OK",null).show() }
    }

    private fun section(parent:LinearLayout,title:String) { parent.addView(TextView(this).apply { text=title; textSize=14f; setTextColor(blue); setPadding(dp(10),dp(17),dp(10),dp(8)) }) }
    private fun settingRow(parent:LinearLayout,title:String,summary:String,onClick:()->Unit) {
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(13),dp(16),dp(13)); setBackgroundColor(if(prefs.getBoolean("dark_mode",false)) Color.rgb(35,40,55) else Color.WHITE); isClickable=true; isFocusable=true; setOnClickListener { onClick() } }
        card.addView(TextView(this).apply { text=title; textSize=17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.WHITE else Color.BLACK) })
        card.addView(TextView(this).apply { text=summary; textSize=14f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); setPadding(0,dp(5),0,0) })
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(6); parent.addView(card,lp)
    }
    private fun toggleSetting(key:String,label:String) { val old=prefs.getBoolean(key,when(key){"alerts","message_bar","json_stream"->true;else->false}); prefs.edit().putBoolean(key,!old).apply(); if(key=="alerts"||key=="muted"||key=="min_priority") startSubscriber(); showSettings() }
    private fun editTextDialog(title:String,value:String,hint:String,onSave:(String)->Unit) { val e=EditText(this).apply { setText(value); this.hint=hint; setSingleLine(true) }; AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->onSave(e.text.toString().trim())}.show() }
    private fun choose(title:String,options:Array<String>,selected:Int,onChosen:(Int)->Unit) { AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected){d,w->d.dismiss();onChosen(w)}.setNegativeButton("Cancel",null).show() }
    private fun showCredentialsDialog() {
        val user=EditText(this).apply { hint="Username"; setSingleLine(true); setText(prefs.getString("username", "")) }
        val pass=EditText(this).apply { hint="Password"; setSingleLine(true); inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("password", "")) }
        val b=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),0,dp(20),0); addView(user); addView(pass) }
        AlertDialog.Builder(this).setTitle("Account / authentication").setMessage("Use credentials supplied by your ntfy server administrator. Public ntfy.sh topics do not require an account; account creation is server-dependent.").setView(b).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_-> prefs.edit().putString("username",user.text.toString()).putString("password",pass.text.toString()).apply(); startSubscriber(); toast("Credentials saved on this device.") }.show()
    }
    private fun showHeadersDialog() {
        val e=EditText(this).apply { hint="Header-Name: value (one per line)"; minLines=5; gravity=Gravity.TOP; setText(prefs.getString("custom_headers","")) }
        AlertDialog.Builder(this).setTitle("Custom HTTP headers").setMessage("Enter one header per line, for example: Authorization: Bearer YOUR_TOKEN").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_-> prefs.edit().putString("custom_headers",e.text.toString()).apply(); startSubscriber(); toast("Headers saved.") }.show()
    }
    private fun manageSubscriptions() { val ts=topics(); if(ts.isEmpty()){toast("No subscriptions to manage.");return}; AlertDialog.Builder(this).setTitle("Manage subscriptions").setItems(ts.toTypedArray()){_,i->val topic=ts[i];AlertDialog.Builder(this).setTitle(topic).setItems(arrayOf("Open topic","Copy topic","Unsubscribe")){_,w->when(w){0->showTopic(topic);1->copy(topic);2->AlertDialog.Builder(this).setMessage("Unsubscribe from $topic?").setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->saveTopics(topics().filterNot{it==topic});showSettings()}.show()}}.show()}.show() }

    private fun showTopic(topic:String) {
        val muted = try { val a=JSONArray(prefs.getString("muted_topics","[]")); (0 until a.length()).any { a.optString(it)==topic } } catch (_:Exception) { false }
        AlertDialog.Builder(this).setTitle(topic).setItems(arrayOf("View recent notifications","Send a notification","Copy topic",if(muted) "Unmute this topic" else "Mute this topic","Unsubscribe")){_,w->when(w){0->showTopicMessages(topic);1->showPublishDialog(topic);2->copy(topic);3->{val a=try{JSONArray(prefs.getString("muted_topics","[]"))}catch(_:Exception){JSONArray()};val keep=(0 until a.length()).map{a.optString(it)}.filter{it!=topic}.toMutableList();if(!muted)keep.add(topic);prefs.edit().putString("muted_topics",JSONArray(keep).toString()).apply();toast(if(muted)"Topic unmuted" else "Topic muted");showTopics()};4->AlertDialog.Builder(this).setTitle("Unsubscribe?").setMessage("Remove $topic from this device?").setNegativeButton("Cancel",null).setPositiveButton("Unsubscribe"){_,_->saveTopics(topics().filterNot{it==topic});showTopics()}.show()}}.show()
    }
    private fun showTopicMessages(topic:String) {
        val a=try{JSONArray(prefs.getString("messages","[]"))}catch(_:Exception){JSONArray()}
        val lines=(a.length()-1 downTo 0).mapNotNull{i->a.optJSONObject(i)?.takeIf{it.optString("topic")==topic}?.let{"${it.optString("title",topic)}\n${it.optString("body")}\n${it.optString("time")}"}}
        val dialog=AlertDialog.Builder(this).setTitle(topic).setMessage(if(lines.isEmpty())"No notifications received on this device yet." else lines.take(30).joinToString("\n\n"))
        if(prefs.getBoolean("message_bar",true)) dialog.setPositiveButton("Send message"){_,_->showPublishDialog(topic)}
        dialog.setNeutralButton("Copy topic"){_,_->copy(topic)}.setNegativeButton("Close",null).show()
    }
    private fun showPublishDialog(topic:String) { val title=EditText(this).apply{hint="Title (optional)";setSingleLine(true)};val message=EditText(this).apply{hint="Message";minLines=3;gravity=Gravity.TOP};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(6),dp(20),0);addView(title);addView(message)};AlertDialog.Builder(this).setTitle("Send to $topic").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Publish"){_,_->val text=message.text.toString().trim();if(text.isBlank()){toast("Enter a message.");return@setPositiveButton};executor.execute{try{val c=URL("$server/${encodeTopic(topic)}").openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=8000;c.readTimeout=8000;c.doOutput=true;applyHeaders(c);c.setRequestProperty("Content-Type","text/plain; charset=utf-8");val t=title.text.toString().trim();if(t.isNotBlank())c.setRequestProperty("Title",t);c.outputStream.use{it.write(text.toByteArray(Charsets.UTF_8))};val code=c.responseCode;c.disconnect();runOnUiThread{toast(if(code in 200..299)"Notification published to $topic" else "Publish failed (HTTP $code). Check server credentials.")}}catch(e:Exception){runOnUiThread{toast("Publish failed: ${e.message}")}}}}.show() }

    private fun testConnection(candidate:String) { executor.execute { try { val c=URL("$candidate/v1/health").openConnection() as HttpURLConnection;c.connectTimeout=6000;c.readTimeout=6000;applyHeaders(c);val code=c.responseCode;c.disconnect();runOnUiThread{toast(if(code in 200..299)"Server is reachable (HTTP $code)." else "Server responded with HTTP $code.")} } catch(e:Exception){runOnUiThread{toast("Connection failed: ${e.message}")}} } }
    private fun applyHeaders(c:HttpURLConnection) {
        val username=prefs.getString("username","") ?: ""; val password=prefs.getString("password","") ?: ""
        if(username.isNotBlank()) c.setRequestProperty("Authorization","Basic "+android.util.Base64.encodeToString("$username:$password".toByteArray(),android.util.Base64.NO_WRAP))
        prefs.getString("custom_headers","")?.lineSequence()?.forEach { line-> val i=line.indexOf(':');if(i>0){val key=line.substring(0,i).trim();val value=line.substring(i+1).trim();if(key.isNotBlank())c.setRequestProperty(key,value)} }
    }
    private fun showLogsDialog() {
        val logs = prefs.getString("diagnostic_logs", "") ?: ""
        AlertDialog.Builder(this).setTitle("Trade ntfy diagnostics")
            .setMessage(if (logs.isBlank()) "No diagnostic entries yet." else logs)
            .setPositiveButton("Copy logs") { _, _ -> copy(logs.ifBlank { "No diagnostic entries yet." }) }
            .setNeutralButton("Clear logs") { _, _ -> prefs.edit().putString("diagnostic_logs", "").apply(); toast("Logs cleared."); showSettings() }
            .setNegativeButton("Close", null).show()
    }
    private fun confirmClearHistory() { AlertDialog.Builder(this).setTitle("Clear notification history?").setMessage("This removes locally stored notifications from this device.").setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->prefs.edit().putString("messages","[]").apply();topics().forEach{prefs.edit().putInt("count_$it",0).apply()};toast("Notification history cleared.");if(currentScreen=="settings")showSettings() else showTopics()}.show() }
    private fun pruneHistory() { val days=prefs.getInt("retention_days",30);if(days<=0)return;val cutoff=System.currentTimeMillis()-days*86400000L;val old=try{JSONArray(prefs.getString("messages","[]"))}catch(_:Exception){JSONArray()};val fresh=JSONArray();for(i in 0 until old.length()){val o=old.optJSONObject(i)?:continue;try{val millis=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.getDefault()).parse(o.optString("time"))?.time?:0;if(millis>=cutoff)fresh.put(o)}catch(_:Exception){fresh.put(o)}};prefs.edit().putString("messages",fresh.toString()).apply() }
    private fun createBackupFile() { val i=Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"trade-ntfy-backup.json");backupLauncher.launch(i) }
    private val backupLauncher=registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK){val uri=r.data?.data?:return@registerForActivityResult;try{val obj=JSONObject().put("server",server).put("topics",JSONArray(topics())).put("settings",JSONObject().put("alerts",prefs.getBoolean("alerts",true)).put("muted",prefs.getBoolean("muted",false)).put("dark_mode",prefs.getBoolean("dark_mode",false)).put("message_bar",prefs.getBoolean("message_bar",true)).put("min_priority",prefs.getInt("min_priority",1)).put("retention_days",prefs.getInt("retention_days",30)).put("json_stream",prefs.getBoolean("json_stream",true)).put("repeat_urgent",prefs.getBoolean("repeat_urgent",false)).put("record_logs",prefs.getBoolean("record_logs",false)).put("muted_topics",JSONArray(prefs.getString("muted_topics","[]"))));contentResolver.openOutputStream(uri)?.use{it.write(obj.toString(2).toByteArray())};toast("Backup saved.")}catch(e:Exception){toast("Backup failed: ${e.message}")}} }
    private fun openBackupFile() { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE);restoreLauncher.launch(i) }
    private val restoreLauncher=registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK){val uri=r.data?.data?:return@registerForActivityResult;try{val obj=JSONObject(contentResolver.openInputStream(uri)!!.bufferedReader().readText());val ts=obj.optJSONArray("topics")?:JSONArray();val items=(0 until ts.length()).map{ts.getString(it)};prefs.edit().putString("server",obj.optString("server","https://ntfy.sh")).putString("topics",JSONArray(items).toString()).apply();val s=obj.optJSONObject("settings");if(s!=null){val e=prefs.edit();listOf("alerts","muted","dark_mode","message_bar","json_stream","repeat_urgent","record_logs").forEach{key->if(s.has(key))e.putBoolean(key,s.getBoolean(key))};if(s.has("muted_topics"))e.putString("muted_topics",s.getJSONArray("muted_topics").toString());if(s.has("min_priority"))e.putInt("min_priority",s.getInt("min_priority"));if(s.has("retention_days"))e.putInt("retention_days",s.getInt("retention_days"));e.apply()};startSubscriber();showSettings();toast("Backup restored.")}catch(e:Exception){toast("Restore failed: ${e.message}")}} }
    private fun shareApp() { val i=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,"Trade ntfy").putExtra(Intent.EXTRA_TEXT,"Trade ntfy — general-purpose topic notifications. https://github.com/TaaHope/trade-ntfy-android-");startActivity(Intent.createChooser(i,"Share Trade ntfy")) }
    private fun startSubscriber() { try{ContextCompat.startForegroundService(this,Intent(this,NtfySubscriptionService::class.java).apply{action=NtfySubscriptionService.ACTION_RESTART})}catch(_:Exception){} }
    private fun createChannel() { if(Build.VERSION.SDK_INT>=26){val m=getSystemService(NotificationManager::class.java);m.createNotificationChannel(NotificationChannel("trade_ntfy_messages","Topic notifications",NotificationManager.IMPORTANCE_HIGH));m.createNotificationChannel(NotificationChannel("trade_ntfy_connection","Trade ntfy connection",NotificationManager.IMPORTANCE_LOW))} }
    private fun validTopic(s:String)=s.matches(Regex("[A-Za-z0-9._-]{1,64}"));private fun encodeTopic(s:String)=URLEncoder.encode(s,"UTF-8").replace("+","%20")
    private fun copy(s:String){(getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Topic",s));toast("Topic copied")};private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show();private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
