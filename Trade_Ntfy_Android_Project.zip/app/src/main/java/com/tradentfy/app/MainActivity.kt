package com.tradentfy.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.RingtoneManager
import android.media.Ringtone
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var currentScreen = "topics"
    private var activeChatTopic: String? = null
    private val incomingMessageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val topic = intent?.getStringExtra("topic") ?: return
            if (currentScreen == "chat" && activeChatTopic == topic) showTopicChat(topic)
            else if (currentScreen == "topics" && ::list.isInitialized) showTopics()
        }
    }
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val server: String get() = prefs.getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')
    private val blue = Color.rgb(48, 91, 222)
    private val navy = Color.rgb(18, 35, 82)
    private val pale = Color.rgb(235, 249, 239) // light green canvas; blue header remains unchanged

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        showTopics(); startSubscriber()
        try { ContextCompat.registerReceiver(this, incomingMessageReceiver, IntentFilter(NtfySubscriptionService.ACTION_MESSAGE), ContextCompat.RECEIVER_NOT_EXPORTED) } catch (_: Exception) { }
    }
    override fun onDestroy() { try { unregisterReceiver(incomingMessageReceiver) } catch (_: Exception) { }; executor.shutdownNow(); super.onDestroy() }
    override fun onResume() { super.onResume(); if (currentScreen == "topics" && ::list.isInitialized) showTopics() }

    private fun topics(): MutableList<String> {
        val arr = try { JSONArray(prefs.getString("topics", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }.distinct().toMutableList()
    }
    private fun saveTopics(items: List<String>) { prefs.edit().putString("topics", JSONArray(items.distinct()).toString()).apply(); startSubscriber() }

    private fun baseScreen(title: String, subtitle: String? = null): LinearLayout {
        currentScreen = when (title) { "Settings" -> "settings"; "Subscribed topics" -> "topics"; else -> "chat" }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (prefs.getBoolean("dark_mode", false)) Color.rgb(20, 24, 35) else pale)
            // Apply the real Android navigation-bar inset so the composer and + button
            // remain fully above the system navigation area on gesture and button navigation.
            ViewCompat.setOnApplyWindowInsetsListener(this) { view, windowInsets ->
                val bars = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars())
                view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, bars.bottom)
                windowInsets
            }
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(13), dp(10), dp(13)); setBackgroundColor(blue) }
        if (title != "Subscribed topics") bar.addView(TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(Color.WHITE); setPadding(0,0,dp(18),0); setOnClickListener { showTopics() } })
        bar.addView(TextView(this).apply { text = title; textSize = 23f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        if (title == "Subscribed topics") bar.addView(TextView(this).apply { text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12),0,dp(12),0); setOnClickListener { showOverflow(this) } })
        root.addView(bar)
        if (subtitle != null) root.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(dp(16),dp(6),dp(16),dp(6)) })
        setContentView(root)
        return root
    }

    private fun showTopics() {
        currentScreen = "topics"
        baseScreen("Subscribed topics", "Server: $server")
        val scroll = ScrollView(this); list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (prefs.getBoolean("dark_mode", false)) Color.rgb(20,24,35) else pale) }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val all = topics()
        if (all.isEmpty()) list.addView(TextView(this).apply { text = "No subscriptions yet.\n\nTap + to add a topic."; textSize = 17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); gravity = Gravity.CENTER; setPadding(dp(28),dp(65),dp(28),dp(65)) })
        else all.forEach { topic ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(17),dp(14),dp(17)); setBackgroundColor(Color.WHITE); setOnClickListener { showTopicChat(topic) }; setOnLongClickListener { showTopic(topic); true } }
            row.addView(TextView(this).apply { text = "▣"; textSize = 29f; setTextColor(blue); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(48),dp(50)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
            texts.addView(TextView(this).apply { text = topic; textSize = 17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.WHITE else navy) })
            texts.addView(TextView(this).apply { text = "${prefs.getInt("count_$topic",0)} notifications"; textSize = 14f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); setPadding(0,dp(3),0,0) })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f)); row.addView(TextView(this).apply { text="›"; textSize=28f; setTextColor(Color.GRAY) })
            list.addView(row); list.addView(View(this).apply { setBackgroundColor(Color.rgb(230,234,244)) },LinearLayout.LayoutParams(-1,dp(1)))
        }
        val fab = TextView(this).apply { text="+"; textSize=36f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(blue); elevation=dp(5).toFloat(); setOnClickListener { showAddTopicDialog() } }
        val fabRow = LinearLayout(this).apply { gravity=Gravity.RIGHT; setPadding(dp(14),dp(8),dp(20),dp(20)); addView(fab,LinearLayout.LayoutParams(dp(64),dp(64))) }
        root.addView(fabRow)
    }

    private fun showOverflow(anchor: View) {
        PopupMenu(this,anchor).apply {
            menu.add("Settings").setOnMenuItemClickListener { showSettings(); true }
            menu.add("Send notification").setOnMenuItemClickListener { val ts=topics(); if(ts.isEmpty()) showAddTopicDialog() else showPublishDialog(ts.first()); true }
            menu.add("Clear notification history").setOnMenuItemClickListener { confirmClearHistory(); true }
            menu.add("Share Trade ntfy").setOnMenuItemClickListener { shareApp(); true }
            menu.add("About").setOnMenuItemClickListener { brandedDialogBuilder().setTitle("Trade ntfy").setMessage("General-purpose topic notifications. Supports ntfy-compatible servers.\n\nVersion 1.7").setPositiveButton("OK",null).show(); true }
            show()
        }
    }

    private fun showAddTopicDialog() {
        val topicInput = EditText(this).apply {
            hint = "e.g. gold_alerts"
            setSingleLine(true)
            setTextColor(if (prefs.getBoolean("dark_mode", false)) Color.WHITE else navy)
        }
        val useOtherServer = CheckBox(this).apply { text = "Use another server"; setTextColor(navy) }
        val serverInput = EditText(this).apply {
            hint = "https://ntfy.sh"
            setSingleLine(true)
            setText(server)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            visibility = View.GONE
        }
        val instantDelivery = CheckBox(this).apply { text = "Instant delivery"; setTextColor(navy) }
        val protectedTopic = CheckBox(this).apply { text = "Protected topic (requires login)"; setTextColor(navy) }
        val username = EditText(this).apply { hint = "Username"; setSingleLine(true); visibility = View.GONE }
        val password = EditText(this).apply {
            hint = "Password"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            visibility = View.GONE
        }
        useOtherServer.setOnCheckedChangeListener { _, checked -> serverInput.visibility = if (checked) View.VISIBLE else View.GONE }
        protectedTopic.setOnCheckedChangeListener { _, checked ->
            username.visibility = if (checked) View.VISIBLE else View.GONE
            password.visibility = if (checked) View.VISIBLE else View.GONE
        }
        val brandHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
            addView(ImageView(this@MainActivity).apply { setImageResource(R.mipmap.ic_launcher); scaleType = android.widget.ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(48), dp(48)))
            val labels = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            labels.addView(TextView(this@MainActivity).apply { text = "Add subscription"; textSize = 20f; setTextColor(navy); setTypeface(null, android.graphics.Typeface.BOLD) })
            labels.addView(TextView(this@MainActivity).apply { text = "Connect to a notification topic"; textSize = 13f; setTextColor(Color.rgb(83, 105, 96)) })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
            setBackgroundColor(Color.rgb(239, 249, 242))
            addView(brandHeader)
            addView(View(this@MainActivity).apply { setBackgroundColor(Color.rgb(214, 231, 220)) }, LinearLayout.LayoutParams(-1, dp(1)))
            addView(TextView(this@MainActivity).apply { text = "Topic name"; textSize = 14f; setTextColor(navy); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(12), 0, dp(2)) })
            addView(topicInput)
            addView(TextView(this@MainActivity).apply { text = "Enter the exact topic name you want to follow."; textSize = 12f; setTextColor(Color.rgb(83, 105, 96)); setPadding(0, dp(2), 0, dp(8)) })
            addView(useOtherServer)
            addView(serverInput)
            addView(instantDelivery)
            addView(protectedTopic)
            addView(username)
            addView(password)
        }
        val dialog = brandedDialogBuilder().setView(box).setNegativeButton("Cancel", null).setPositiveButton("Subscribe", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(blue)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(83, 105, 96))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val topic = topicInput.text.toString().trim()
                val candidate = (if (useOtherServer.isChecked) serverInput.text.toString() else server).trim().trimEnd('/')
                if (!validTopic(topic)) { toast("Use 1–64 letters, numbers, dots, hyphens or underscores."); return@setOnClickListener }
                if (!candidate.startsWith("https://") || candidate.length < 12) { toast("Enter a valid HTTPS server URL."); return@setOnClickListener }
                if (protectedTopic.isChecked && username.text.toString().isBlank()) { toast("Enter the username for this protected topic."); return@setOnClickListener }
                prefs.edit().putString("server", candidate).apply()
                if (protectedTopic.isChecked) prefs.edit().putString("username", username.text.toString().trim()).putString("password", password.text.toString()).apply()
                val items = topics()
                if (topic !in items) items.add(topic)
                saveTopics(items)
                dialog.dismiss()
                showTopics()
                toast(if (instantDelivery.isChecked) "Subscribed to $topic. Instant delivery depends on Android and server support." else "Subscribed to $topic")
            }
        }
        dialog.show()
    }

    private fun showSettings() {
        currentScreen="settings"; baseScreen("Settings")
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(22)) }; scroll.addView(content); root.addView(scroll)
        section(content,"General")
        settingRow(content,"Default server","Server used when adding a subscription · $server") { editTextDialog("Default server URL",server,"https://ntfy.sh") { v -> if(!v.startsWith("https://")) toast("Use an HTTPS URL.") else { prefs.edit().putString("server",v.trim().trimEnd('/')).apply(); startSubscriber(); showSettings() } } }
        settingRow(content,"Manage users","Add, select or remove saved server login profiles") { showUserProfilesDialog() }
        settingRow(content,"Account / authentication","Edit the active server username and password") { showCredentialsDialog() }
        section(content,"General")
        settingRow(content,"Language",if(prefs.getString("language","system")=="sh") "Shona (selected; some screens remain English)" else if(prefs.getString("language","system")=="en") "English" else "System default") { choose("Language",arrayOf("System default","English","Shona"),when(prefs.getString("language","system")){"en"->1;"sh"->2;else->0}) { choice -> prefs.edit().putString("language",when(choice){1->"en";2->"sh";else->"system"}).apply(); toast(if(choice==2) "Shona selected. Some app text is still in English." else "Language preference saved."); showSettings() } }
        section(content,"Notifications")
        settingSwitchRow(content,"Download attachments","Automatically download eligible attachments", "auto_download_attachments", false) { enabled -> if (enabled) choose("Attachment download limit",arrayOf("1 MB","5 MB","10 MB"),0) { choice -> prefs.edit().putInt("attachment_limit_mb",listOf(1,5,10)[choice]).apply(); showSettings() } else showSettings() }
        if (prefs.getBoolean("auto_download_attachments", false)) settingRow(content,"Attachment size limit","Up to ${prefs.getInt("attachment_limit_mb",1)} MB per attachment") { choose("Attachment size limit",arrayOf("1 MB","5 MB","10 MB"),when(prefs.getInt("attachment_limit_mb",1)){5->1;10->2;else->0}) { choice -> prefs.edit().putInt("attachment_limit_mb",listOf(1,5,10)[choice]).apply(); showSettings() } }
        settingSwitchRow(content,"Notification alerts","Show Android alerts for incoming messages", "alerts", true) { startSubscriber() }
        settingRow(content,"Notification ringtone", selectedRingtoneLabel()) { chooseRingtone() }
        settingSwitchRow(content,"Vibrate for notifications","Use vibration with incoming message alerts", "vibrate_notifications", true) { startSubscriber() }
        settingRow(content,"Test ringtone","Play a preview of the selected notification sound") { previewRingtone() }
        settingRow(content,"Minimum priority", "Current: ${prefs.getInt("min_priority",1)} · Tap to change") { choose("Minimum priority",arrayOf("Min (1)","Low (2)","Default (3)","High (4)","Urgent (5)"),prefs.getInt("min_priority",1)-1) { prefs.edit().putInt("min_priority",it+1).apply(); showSettings() } }
        settingSwitchRow(content,"Mute notifications","Temporarily silence all incoming alerts", "muted", false) { startSubscriber() }
        settingSwitchRow(content,"Keep alerting for highest priority","Repeat alerts for urgent messages where supported", "repeat_urgent", false) {}
        settingRow(content,"Channel settings","Android sound, vibration and Do Not Disturb settings") { openChannelSettings() }
        settingRow(content,"Delete notifications","Auto-delete after ${prefs.getInt("retention_days",30)} days") { choose("Delete notifications",arrayOf("Never","7 days","30 days","90 days"),when(prefs.getInt("retention_days",30)){0->0;7->1;30->2;90->3;else->2}) { val days=listOf(0,7,30,90)[it]; prefs.edit().putInt("retention_days",days).apply(); pruneHistory(); showSettings() } }
        section(content,"Appearance")
        settingSwitchRow(content,"Dark mode","Use a dark background for the app", "dark_mode", false) { showSettings() }
        settingSwitchRow(content,"Show message bar","Show the quick message action on topic views", "message_bar", true) {}
        section(content,"Backup & Restore")
        settingRow(content,"Back up to file","Export subscriptions and settings to a JSON file") { createBackupFile() }
        settingRow(content,"Restore from file","Import subscriptions and settings from a JSON file") { openBackupFile() }
        section(content,"Advanced")
        settingSwitchRow(content,"Connection protocol","On: long-lived JSON stream · Off: reconnect more often", "json_stream", true) { startSubscriber() }
        settingRow(content,"Custom headers","Configure HTTP headers for authenticated servers") { showHeadersDialog() }
        settingRow(content,"Manage certificates","Use Android's certificate settings for trusted certificates") { try { startActivity(Intent("android.settings.SECURITY_SETTINGS")) } catch (_:Exception) { toast("Open Android Settings → Security to manage certificates.") } }
        settingSwitchRow(content,"Record logs","Save connection and message events for troubleshooting", "record_logs", false) { showSettings() } 
        if (prefs.getBoolean("record_logs", false)) settingRow(content,"View / clear diagnostic logs","Copy diagnostics or clear the log") { showLogsDialog() }
        settingRow(content,"Manage subscriptions","View or remove saved topics") { manageSubscriptions() }
        settingRow(content,"Clear notification history","Delete all locally saved notifications") { confirmClearHistory() }
        settingRow(content,"Test connection","Check whether the selected server is reachable") { testConnection(server) }
        settingRow(content,"Share Trade ntfy","Share the app link") { shareApp() }
        section(content,"About")
        settingRow(content,"Version","Trade ntfy 1.7") { brandedDialogBuilder().setTitle("Trade ntfy").setMessage("General-purpose notifications for apps, teams and services.").setPositiveButton("OK",null).show() }
    }

    private fun translateLabel(label: String): String {
        if (prefs.getString("language", "system") != "sh") return label
        return mapOf(
            "General" to "Zvakawanda", "Notifications" to "Zviziviso", "Appearance" to "Chitarisiko",
            "Backup & Restore" to "Chengetedza uye Dzorera", "Advanced" to "Zvepamusoro", "About" to "Nezve app",
            "Default server" to "Server yekutanga", "Manage users" to "Tonga vashandisi", "Account / authentication" to "Akaunti / kupinda",
            "Language" to "Mutauro", "Download attachments" to "Dhawunirodha mafaira akabatanidzwa",
            "Notification alerts" to "Yambiro dzezviziviso", "Minimum priority" to "Kukosha kushoma",
            "Mute notifications" to "Nyararidza zviziviso", "Keep alerting for highest priority" to "Ramba uchiyambira pane zvakakosha zvikuru",
            "Channel settings" to "Magadzirirwo ezviziviso", "Delete notifications" to "Dzima zviziviso zvekare",
            "Dark mode" to "Chitarisiko cherima", "Show message bar" to "Ratidza nzvimbo yemashoko",
            "Back up to file" to "Chengetedza kufaira", "Restore from file" to "Dzorera kubva kufaira",
            "Connection protocol" to "Maitiro ekubatanidza", "Custom headers" to "Misoro yekubatanidza yakasarudzwa",
            "Manage certificates" to "Tonga zvitupa", "Record logs" to "Chengetedza marekodhi",
            "Manage subscriptions" to "Tonga misoro yakanyoreswa", "Clear notification history" to "Bvisa nhoroondo yezviziviso",
            "Test connection" to "Edza kubatanidza", "Share Trade ntfy" to "Govera Trade ntfy", "Version" to "Shanduro"
        )[label] ?: label
    }

    private fun section(parent:LinearLayout,title:String) { parent.addView(TextView(this).apply { text=translateLabel(title); textSize=14f; setTextColor(blue); setPadding(dp(10),dp(17),dp(10),dp(8)) }) }
    private fun settingRow(parent:LinearLayout,title:String,summary:String,onClick:()->Unit) {
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(13),dp(16),dp(13)); setBackgroundColor(if(prefs.getBoolean("dark_mode",false)) Color.rgb(35,40,55) else Color.WHITE); isClickable=true; isFocusable=true; setOnClickListener { onClick() } }
        card.addView(TextView(this).apply { text=translateLabel(title); textSize=17f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.WHITE else Color.BLACK) })
        card.addView(TextView(this).apply { text=summary; textSize=14f; setTextColor(if(prefs.getBoolean("dark_mode",false)) Color.LTGRAY else Color.DKGRAY); setPadding(0,dp(5),0,0) })
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(6); parent.addView(card,lp)
    }
    private fun settingSwitchRow(parent: LinearLayout, title: String, summary: String, key: String, defaultValue: Boolean, afterChange: (Boolean) -> Unit) {
        val dark = prefs.getBoolean("dark_mode", false)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(if (dark) Color.rgb(35, 40, 55) else Color.WHITE)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply { text = translateLabel(title); textSize = 16f; setTextColor(if (dark) Color.WHITE else Color.BLACK) })
        texts.addView(TextView(this).apply { text = summary; textSize = 13f; setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY); setPadding(0, dp(4), dp(8), 0) })
        card.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val switch = Switch(this).apply {
            isChecked = prefs.getBoolean(key, defaultValue)
            buttonTintList = android.content.res.ColorStateList.valueOf(if (isChecked) blue else Color.GRAY)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                buttonTintList = android.content.res.ColorStateList.valueOf(if (checked) blue else Color.GRAY)
                afterChange(checked)
                if (key in listOf("dark_mode", "alerts", "muted", "json_stream")) showSettings()
            }
        }
        card.addView(switch)
        card.setOnClickListener { switch.isChecked = !switch.isChecked }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(6); parent.addView(card, lp)
    }

    private fun toggleSetting(key:String,label:String) { val old=prefs.getBoolean(key,when(key){"alerts","message_bar","json_stream"->true;else->false}); prefs.edit().putBoolean(key,!old).apply(); if(key=="alerts"||key=="muted"||key=="min_priority") startSubscriber(); showSettings() }
    private fun editTextDialog(title:String,value:String,hint:String,onSave:(String)->Unit) { val e=EditText(this).apply { setText(value); this.hint=hint; setSingleLine(true) }; brandedDialogBuilder().setTitle(title).setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->onSave(e.text.toString().trim())}.show() }
    private fun choose(title:String,options:Array<String>,selected:Int,onChosen:(Int)->Unit) { brandedDialogBuilder().setTitle(title).setSingleChoiceItems(options,selected){d,w->d.dismiss();onChosen(w)}.setNegativeButton("Cancel",null).show() }
    private fun showUserProfilesDialog() {
        val profiles = try { JSONArray(prefs.getString("user_profiles", "[]")) } catch (_: Exception) { JSONArray() }
        if (profiles.length() == 0) {
            val username = prefs.getString("username", "") ?: ""
            val password = prefs.getString("password", "") ?: ""
            if (username.isNotBlank()) profiles.put(JSONObject().put("name", username).put("username", username).put("password", password))
        }
        val names = (0 until profiles.length()).map { i -> profiles.optJSONObject(i)?.optString("name", "Account ${i+1}") ?: "Account ${i+1}" }.toMutableList()
        names.add("+ Add user / login")
        brandedDialogBuilder().setTitle("Manage users")
            .setMessage("These are saved login profiles for protected topics on the selected server. Creating server-side users or changing their permissions must be done by the server administrator.")
            .setItems(names.toTypedArray()) { _, index ->
                if (index == names.lastIndex) {
                    showProfileEditor(null, profiles)
                } else {
                    val profile = profiles.optJSONObject(index) ?: return@setItems
                    brandedDialogBuilder().setTitle(profile.optString("name", "User"))
                        .setItems(arrayOf("Use this login", "Edit login", "Remove saved login")) { _, action ->
                            when (action) {
                                0 -> { prefs.edit().putString("username", profile.optString("username")).putString("password", profile.optString("password")).apply(); startSubscriber(); toast("Active login changed.") }
                                1 -> showProfileEditor(profile, profiles)
                                2 -> brandedDialogBuilder().setMessage("Remove this saved login from this device?").setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ ->
                                    val updated = JSONArray(); for (i in 0 until profiles.length()) if (i != index) updated.put(profiles.getJSONObject(i))
                                    prefs.edit().putString("user_profiles", updated.toString()).apply(); toast("Saved login removed."); showSettings()
                                }.show()
                            }
                        }.show()
                }
            }.setNegativeButton("Close", null).show()
    }

    private fun showProfileEditor(existing: JSONObject?, profiles: JSONArray) {
        val name = EditText(this).apply { hint = "Profile name"; setSingleLine(true); setText(existing?.optString("name", "") ?: "") }
        val username = EditText(this).apply { hint = "Username"; setSingleLine(true); setText(existing?.optString("username", "") ?: "") }
        val password = EditText(this).apply { hint = "Password"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(existing?.optString("password", "") ?: "") }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0); addView(name); addView(username); addView(password) }
        brandedDialogBuilder().setTitle(if (existing == null) "Add user / login" else "Edit user / login").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim(); val u = username.text.toString().trim(); val pw = password.text.toString()
                if (n.isBlank() || u.isBlank()) { toast("Enter a profile name and username."); return@setPositiveButton }
                val updated = JSONArray(); var replaced = false
                for (i in 0 until profiles.length()) {
                    val item = profiles.optJSONObject(i) ?: continue
                    if (existing != null && item === existing) { updated.put(JSONObject().put("name", n).put("username", u).put("password", pw)); replaced = true } else updated.put(item)
                }
                if (!replaced) updated.put(JSONObject().put("name", n).put("username", u).put("password", pw))
                prefs.edit().putString("user_profiles", updated.toString()).putString("username", u).putString("password", pw).apply()
                startSubscriber(); toast("Login saved and selected."); showSettings()
            }.show()
    }

    private fun showCredentialsDialog() {
        val user=EditText(this).apply { hint="Username"; setSingleLine(true); setText(prefs.getString("username", "")) }
        val pass=EditText(this).apply { hint="Password"; setSingleLine(true); inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("password", "")) }
        val b=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),0,dp(20),0); addView(user); addView(pass) }
        brandedDialogBuilder().setTitle("Account / authentication").setMessage("Use credentials supplied by your ntfy server administrator. Public ntfy.sh topics do not require an account; account creation is server-dependent.").setView(b).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_-> prefs.edit().putString("username",user.text.toString()).putString("password",pass.text.toString()).apply(); startSubscriber(); toast("Credentials saved on this device.") }.show()
    }
    private fun showHeadersDialog() {
        val e=EditText(this).apply { hint="Header-Name: value (one per line)"; minLines=5; gravity=Gravity.TOP; setText(prefs.getString("custom_headers","")) }
        brandedDialogBuilder().setTitle("Custom HTTP headers").setMessage("Enter one header per line, for example: Authorization: Bearer YOUR_TOKEN").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_-> prefs.edit().putString("custom_headers",e.text.toString()).apply(); startSubscriber(); toast("Headers saved.") }.show()
    }
    private fun manageSubscriptions() { val ts=topics(); if(ts.isEmpty()){toast("No subscriptions to manage.");return}; brandedDialogBuilder().setTitle("Manage subscriptions").setItems(ts.toTypedArray()){_,i->val topic=ts[i];brandedDialogBuilder().setTitle(topic).setItems(arrayOf("Open topic","Copy topic","Unsubscribe")){_,w->when(w){0->showTopicChat(topic);1->copy(topic);2->brandedDialogBuilder().setMessage("Unsubscribe from $topic?").setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->saveTopics(topics().filterNot{it==topic});showSettings()}.show()}}.show()}.show() }

    private fun showTopic(topic:String) {
        val muted = try { val a=JSONArray(prefs.getString("muted_topics","[]")); (0 until a.length()).any { a.optString(it)==topic } } catch (_:Exception) { false }
        brandedDialogBuilder().setTitle(topic).setItems(arrayOf("View recent notifications","Send a notification","Copy topic",if(muted) "Unmute this topic" else "Mute this topic","Unsubscribe")){_,w->when(w){0->showTopicMessages(topic);1->showPublishDialog(topic);2->copy(topic);3->{val a=try{JSONArray(prefs.getString("muted_topics","[]"))}catch(_:Exception){JSONArray()};val keep=(0 until a.length()).map{a.optString(it)}.filter{it!=topic}.toMutableList();if(!muted)keep.add(topic);prefs.edit().putString("muted_topics",JSONArray(keep).toString()).apply();toast(if(muted)"Topic unmuted" else "Topic muted");showTopics()};4->brandedDialogBuilder().setTitle("Unsubscribe?").setMessage("Remove $topic from this device?").setNegativeButton("Cancel",null).setPositiveButton("Unsubscribe"){_,_->saveTopics(topics().filterNot{it==topic});showTopics()}.show()}}.show()
    }
    private fun showTopicMessages(topic:String) = showTopicChat(topic)

    private fun showTopicChat(topic: String) {
        activeChatTopic = topic
        currentScreen = "chat"
        baseScreen(topic)
        val dark = prefs.getBoolean("dark_mode", false)
        val chatScroll = ScrollView(this).apply { isFillViewport = true }
        val chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(16))
            setBackgroundColor(if (dark) Color.rgb(20,24,35) else pale)
        }
        chatScroll.addView(chatList)
        root.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun renderHistory() {
            chatList.removeAllViews()
            val all = try { JSONArray(prefs.getString("messages", "[]")) } catch (_: Exception) { JSONArray() }
            val messages = (0 until all.length()).mapNotNull { all.optJSONObject(it) }
                .filter { it.optString("topic") == topic }
            if (messages.isEmpty()) {
                chatList.addView(TextView(this).apply {
                    text = "No messages saved on this device yet.\n\nMessages received while subscribed will appear here. Use the message box below to send a test message."
                    textSize = 15f; gravity = Gravity.CENTER; setPadding(dp(22), dp(60), dp(22), dp(60))
                    setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY)
                })
            } else {
                messages.forEach { item ->
                    val bubble = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(14), dp(10), dp(14), dp(10))
                        background = android.graphics.drawable.GradientDrawable().apply {
                            setColor(if (dark) Color.rgb(39,48,63) else Color.WHITE)
                            cornerRadius = dp(16).toFloat()
                            setStroke(dp(1), if (dark) Color.rgb(63,76,96) else Color.rgb(215,231,220))
                        }
                    }
                    val titleText = item.optString("title").ifBlank { topic }
                    bubble.addView(TextView(this).apply { text = titleText; textSize = 15f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(if (dark) Color.WHITE else navy) })
                    bubble.addView(TextView(this).apply { text = item.optString("body", ""); textSize = 16f; setTextColor(if (dark) Color.LTGRAY else Color.rgb(35,42,42)); setPadding(0, dp(5), 0, dp(7)) })
                    bubble.addView(TextView(this).apply { text = item.optString("time", ""); textSize = 11f; gravity = Gravity.RIGHT; setTextColor(if (dark) Color.LTGRAY else Color.rgb(83,105,96)) })
                    val targetUrl = item.optString("target_url", "")
                    if (targetUrl.isNotBlank()) {
                        bubble.addView(TextView(this).apply {
                            text = "Open linked page ↗"; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD)
                            setTextColor(blue); setPadding(0, dp(8), 0, 0)
                            setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))) } catch (_: Exception) { toast("No browser can open this address.") } }
                        })
                    }
                    val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9)
                    chatList.addView(bubble, lp)
                }
            }
            chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
        }
        renderHistory()

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(if (dark) Color.rgb(28,32,43) else Color.WHITE)
        }
        val input = EditText(this).apply {
            hint = "Type a message here"; minLines = 1; maxLines = 4
            setTextColor(if (dark) Color.WHITE else Color.BLACK)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (dark) Color.LTGRAY else Color.rgb(83,137,119)))
        }
        val send = TextView(this).apply {
            text = "➤"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(dp(16), dp(8), dp(16), dp(8)); setBackgroundColor(blue)
        }
        send.setOnClickListener {
            val body = input.text.toString().trim()
            if (body.isBlank()) { toast("Type a message first."); return@setOnClickListener }
            send.isEnabled = false
            executor.execute {
                var code = -1
                var error: String? = null
                try {
                    val c = URL("$server/${encodeTopic(topic)}").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 8000; c.doOutput = true
                    applyHeaders(c); c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    code = c.responseCode; c.disconnect()
                } catch (e: Exception) { error = e.message ?: "connection error" }
                runOnUiThread {
                    send.isEnabled = true
                    if (code in 200..299) { input.setText(""); toast("Message sent."); loadRemoteHistory(topic) { renderHistory() } }
                    else toast("Send failed${if (code > 0) " (HTTP $code)" else ""}: ${error ?: "check server and credentials"}")
                }
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(send, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        root.addView(composer)
        loadRemoteHistory(topic) { renderHistory() }
    }

    private fun loadRemoteHistory(topic: String, done: () -> Unit) {
        executor.execute {
            try {
                val c = URL("$server/${encodeTopic(topic)}/json?poll=1&since=24h").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 10000; c.setRequestProperty("Accept", "application/json"); applyHeaders(c)
                if (c.responseCode in 200..299) {
                    val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val existing = try { JSONArray(prefs.getString("messages", "[]")) } catch (_: Exception) { JSONArray() }
                    val known = HashSet<String>()
                    for (i in 0 until existing.length()) {
                        val o = existing.optJSONObject(i) ?: continue
                        known.add(listOf(o.optString("topic"), o.optString("time"), o.optString("title"), o.optString("body")).joinToString("|"))
                    }
                    val fresh = JSONArray()
                    for (i in 0 until existing.length()) fresh.put(existing.getJSONObject(i))
                    text.lineSequence().filter { it.isNotBlank() }.forEach { line ->
                        try {
                            val event = JSONObject(line)
                            if (event.optString("event") != "message") return@forEach
                            val millis = event.optLong("time", System.currentTimeMillis() / 1000) * 1000
                            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(millis))
                            val title = event.optString("title").ifBlank { topic }; val body = event.optString("message").ifBlank { "New notification" }
                            val key = listOf(topic, stamp, title, body).joinToString("|")
                            if (known.add(key)) {
                                val saved = JSONObject().put("topic", topic).put("title", title).put("body", body).put("time", stamp)
                                val target = event.optString("click", event.optString("url", event.optString("link", ""))).trim()
                                if (target.startsWith("https://") || target.startsWith("http://")) saved.put("target_url", target)
                                fresh.put(saved)
                            }
                        } catch (_: Exception) { }
                    }
                    val trimmed = JSONArray(); for (i in (fresh.length() - 500).coerceAtLeast(0) until fresh.length()) trimmed.put(fresh.getJSONObject(i))
                    prefs.edit().putString("messages", trimmed.toString()).apply()
                }
                c.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { if (activeChatTopic == topic && currentScreen == "chat") done() }
        }
    }

    private fun showPublishDialog(topic:String) { val title=EditText(this).apply{hint="Title (optional)";setSingleLine(true)};val message=EditText(this).apply{hint="Message";minLines=3;gravity=Gravity.TOP};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(6),dp(20),0);addView(title);addView(message)};brandedDialogBuilder().setTitle("Send to $topic").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Publish"){_,_->val text=message.text.toString().trim();if(text.isBlank()){toast("Enter a message.");return@setPositiveButton};executor.execute{try{val c=URL("$server/${encodeTopic(topic)}").openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=8000;c.readTimeout=8000;c.doOutput=true;applyHeaders(c);c.setRequestProperty("Content-Type","text/plain; charset=utf-8");val t=title.text.toString().trim();if(t.isNotBlank())c.setRequestProperty("Title",t);c.outputStream.use{it.write(text.toByteArray(Charsets.UTF_8))};val code=c.responseCode;c.disconnect();runOnUiThread{toast(if(code in 200..299)"Notification published to $topic" else "Publish failed (HTTP $code). Check server credentials.")}}catch(e:Exception){runOnUiThread{toast("Publish failed: ${e.message}")}}}}.show() }

    private fun testConnection(candidate:String) { executor.execute { try { val c=URL("$candidate/v1/health").openConnection() as HttpURLConnection;c.connectTimeout=6000;c.readTimeout=6000;applyHeaders(c);val code=c.responseCode;c.disconnect();runOnUiThread{toast(if(code in 200..299)"Server is reachable (HTTP $code)." else "Server responded with HTTP $code.")} } catch(e:Exception){runOnUiThread{toast("Connection failed: ${e.message}")}} } }
    private fun applyHeaders(c:HttpURLConnection) {
        val username=prefs.getString("username","") ?: ""; val password=prefs.getString("password","") ?: ""
        if(username.isNotBlank()) c.setRequestProperty("Authorization","Basic "+android.util.Base64.encodeToString("$username:$password".toByteArray(),android.util.Base64.NO_WRAP))
        prefs.getString("custom_headers","")?.lineSequence()?.forEach { line-> val i=line.indexOf(':');if(i>0){val key=line.substring(0,i).trim();val value=line.substring(i+1).trim();if(key.isNotBlank())c.setRequestProperty(key,value)} }
    }
    private fun showLogsDialog() {
        val logs = prefs.getString("diagnostic_logs", "") ?: ""
        brandedDialogBuilder().setTitle("Trade ntfy diagnostics")
            .setMessage(if (logs.isBlank()) "No diagnostic entries yet." else logs)
            .setPositiveButton("Copy logs") { _, _ -> copy(logs.ifBlank { "No diagnostic entries yet." }) }
            .setNeutralButton("Clear logs") { _, _ -> prefs.edit().putString("diagnostic_logs", "").apply(); toast("Logs cleared."); showSettings() }
            .setNegativeButton("Close", null).show()
    }
    private fun confirmClearHistory() { brandedDialogBuilder().setTitle("Clear notification history?").setMessage("This removes locally stored notifications from this device.").setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->prefs.edit().putString("messages","[]").apply();topics().forEach{prefs.edit().putInt("count_$it",0).apply()};toast("Notification history cleared.");if(currentScreen=="settings")showSettings() else showTopics()}.show() }
    private fun pruneHistory() { val days=prefs.getInt("retention_days",30);if(days<=0)return;val cutoff=System.currentTimeMillis()-days*86400000L;val old=try{JSONArray(prefs.getString("messages","[]"))}catch(_:Exception){JSONArray()};val fresh=JSONArray();for(i in 0 until old.length()){val o=old.optJSONObject(i)?:continue;try{val millis=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.getDefault()).parse(o.optString("time"))?.time?:0;if(millis>=cutoff)fresh.put(o)}catch(_:Exception){fresh.put(o)}};prefs.edit().putString("messages",fresh.toString()).apply() }
    private fun createBackupFile() { val i=Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"trade-ntfy-backup.json");backupLauncher.launch(i) }
    private val backupLauncher=registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK){val uri=r.data?.data?:return@registerForActivityResult;try{val obj=JSONObject().put("server",server).put("topics",JSONArray(topics())).put("settings",JSONObject().put("alerts",prefs.getBoolean("alerts",true)).put("muted",prefs.getBoolean("muted",false)).put("dark_mode",prefs.getBoolean("dark_mode",false)).put("message_bar",prefs.getBoolean("message_bar",true)).put("min_priority",prefs.getInt("min_priority",1)).put("retention_days",prefs.getInt("retention_days",30)).put("json_stream",prefs.getBoolean("json_stream",true)).put("repeat_urgent",prefs.getBoolean("repeat_urgent",false)).put("record_logs",prefs.getBoolean("record_logs",false)).put("auto_download_attachments",prefs.getBoolean("auto_download_attachments",false)).put("vibrate_notifications",prefs.getBoolean("vibrate_notifications",true)).put("notification_sound_uri",prefs.getString("notification_sound_uri","")).put("attachment_limit_mb",prefs.getInt("attachment_limit_mb",1)).put("language",prefs.getString("language","system")).put("muted_topics",JSONArray(prefs.getString("muted_topics","[]"))));contentResolver.openOutputStream(uri)?.use{it.write(obj.toString(2).toByteArray())};toast("Backup saved.")}catch(e:Exception){toast("Backup failed: ${e.message}")}} }
    private fun openBackupFile() { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE);restoreLauncher.launch(i) }
    private val restoreLauncher=registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK){val uri=r.data?.data?:return@registerForActivityResult;try{val obj=JSONObject(contentResolver.openInputStream(uri)!!.bufferedReader().readText());val ts=obj.optJSONArray("topics")?:JSONArray();val items=(0 until ts.length()).map{ts.getString(it)};prefs.edit().putString("server",obj.optString("server","https://ntfy.sh")).putString("topics",JSONArray(items).toString()).apply();val s=obj.optJSONObject("settings");if(s!=null){val e=prefs.edit();listOf("alerts","muted","dark_mode","message_bar","json_stream","repeat_urgent","record_logs","auto_download_attachments","vibrate_notifications").forEach{key->if(s.has(key))e.putBoolean(key,s.getBoolean(key))};if(s.has("muted_topics"))e.putString("muted_topics",s.getJSONArray("muted_topics").toString());if(s.has("notification_sound_uri"))e.putString("notification_sound_uri",s.getString("notification_sound_uri"));if(s.has("min_priority"))e.putInt("min_priority",s.getInt("min_priority"));if(s.has("retention_days"))e.putInt("retention_days",s.getInt("retention_days"));if(s.has("attachment_limit_mb"))e.putInt("attachment_limit_mb",s.getInt("attachment_limit_mb"));if(s.has("language"))e.putString("language",s.getString("language"));e.apply()};startSubscriber();createChannel();showSettings();toast("Backup restored.")}catch(e:Exception){toast("Restore failed: ${e.message}")}} }
    private fun shareApp() { val i=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,"Trade ntfy").putExtra(Intent.EXTRA_TEXT,"Trade ntfy — general-purpose topic notifications. https://github.com/TaaHope/trade-ntfy-android-");startActivity(Intent.createChooser(i,"Share Trade ntfy")) }
    private fun startSubscriber() { try{ContextCompat.startForegroundService(this,Intent(this,NtfySubscriptionService::class.java).apply{action=NtfySubscriptionService.ACTION_RESTART})}catch(_:Exception){} }
    private val ringtonePicker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            prefs.edit().putString("notification_sound_uri", if (picked == null) "silent" else picked.toString()).apply()
            createChannel()
            toast("Notification ringtone saved.")
            showSettings()
        }
    }

    private fun chooseRingtone() {
        val current = prefs.getString("notification_sound_uri", "") ?: ""
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose Trade ntfy ringtone")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, if (current.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(current))
        }
        ringtonePicker.launch(intent)
    }

    private fun selectedRingtoneLabel(): String {
        val saved = prefs.getString("notification_sound_uri", "") ?: ""
        if (saved.isBlank()) return "System default notification sound · Tap to change"
        if (saved == "silent") return "Silent · Tap to change"
        return try { RingtoneManager.getRingtone(this, Uri.parse(saved))?.getTitle(this) ?: "Custom ringtone · Tap to change" } catch (_: Exception) { "Custom ringtone · Tap to change" }
    }

    private fun openChannelSettings() {
        if (Build.VERSION.SDK_INT >= 26) {
            createChannel()
            val sound = prefs.getString("notification_sound_uri", "") ?: ""
            val id = notificationChannelId(sound, prefs.getBoolean("vibrate_notifications", true))
            val intent = Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
                .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, id)
            try { startActivity(intent) } catch (_: Exception) {
                startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
            }
        } else {
            try { startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra("app_package", packageName).putExtra("app_uid", applicationInfo.uid)) }
            catch (_: Exception) { toast("Open Android Settings → Apps → Trade ntfy → Notifications.") }
        }
    }

    private fun previewRingtone() {
        val saved = prefs.getString("notification_sound_uri", "") ?: ""
        if (saved == "silent") { toast("Ringtone is set to silent."); return }
        val uri = if (saved.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(saved)
        try {
            val ringtone = RingtoneManager.getRingtone(this, uri)
            if (ringtone == null) { toast("No ringtone is selected."); return }
            if (Build.VERSION.SDK_INT >= 21) ringtone.audioAttributes = android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ringtone.play()
            toast("Playing ringtone preview…")
            android.os.Handler(mainLooper).postDelayed({ try { ringtone.stop() } catch (_: Exception) {} }, 3500)
        } catch (_: Exception) { toast("Unable to preview this ringtone.") }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val m = getSystemService(NotificationManager::class.java)
            val sound = prefs.getString("notification_sound_uri", "") ?: ""
            val vibrate = prefs.getBoolean("vibrate_notifications", true)
            val channelId = notificationChannelId(sound, vibrate)
            val channel = NotificationChannel(channelId, "Topic notifications", NotificationManager.IMPORTANCE_HIGH)
            val uri = if (sound.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else if (sound == "silent") null else Uri.parse(sound)
            channel.setSound(uri, android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            channel.enableVibration(vibrate)
            if (vibrate) channel.vibrationPattern = longArrayOf(0, 250, 150, 250)
            m.createNotificationChannel(channel)
            m.createNotificationChannel(NotificationChannel("trade_ntfy_connection", "Trade ntfy connection", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notificationChannelId(sound: String, vibrate: Boolean): String = "trade_ntfy_messages_" + Integer.toHexString((sound + "|" + vibrate).hashCode())
    private fun brandedDialogBuilder(): AlertDialog.Builder = AlertDialog.Builder(this, R.style.TradeAlertDialogTheme).setIcon(R.mipmap.ic_launcher)
    private fun validTopic(s:String)=s.matches(Regex("[A-Za-z0-9._-]{1,64}"));private fun encodeTopic(s:String)=URLEncoder.encode(s,"UTF-8").replace("+","%20")
    private fun copy(s:String){(getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Topic",s));toast("Topic copied")};private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show();private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
