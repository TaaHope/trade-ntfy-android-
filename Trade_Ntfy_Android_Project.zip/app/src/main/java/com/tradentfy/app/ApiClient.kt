package com.tradentfy.app

import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter

object ApiClient {
    private const val PREFS = "trade_ntfy_settings"
    fun baseUrl(): String = MainActivity.appContext.getSharedPreferences(PREFS, 0)
        .getString("backend_url", "")!!.trim().trimEnd('/')

    fun saveBaseUrl(value: String) {
        MainActivity.appContext.getSharedPreferences(PREFS, 0).edit()
            .putString("backend_url", value.trim().trimEnd('/')).apply()
    }

    fun request(method: String, path: String, payload: JSONObject? = null): JSONObject {
        val base = baseUrl()
        require(base.startsWith("https://")) { "Set the HTTPS backend URL in Settings first." }
        val user = FirebaseAuth.getInstance().currentUser ?: error("Sign in first.")
        val idToken = Tasks.await(user.getIdToken(false)).token ?: error("Could not obtain sign-in token.")
        val connection = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Authorization", "Bearer $idToken")
            setRequestProperty("Accept", "application/json")
            if (payload != null) setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            if (payload != null) {
                connection.doOutput = true
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val result = try { JSONObject(text) } catch (_: Exception) { JSONObject().put("message", text) }
            if (code !in 200..299) throw IllegalStateException(result.optString("error", result.optString("message", "Request failed ($code)")))
            return result
        } finally { connection.disconnect() }
    }

    fun registerDevice(token: String) {
        if (baseUrl().isBlank() || FirebaseAuth.getInstance().currentUser == null || token.isBlank()) return
        request("POST", "/api/device", JSONObject().put("token", token).put("device_name", android.os.Build.MODEL))
    }

    fun parseTopics(result: JSONObject): JSONArray = result.optJSONArray("topics") ?: JSONArray()
}
