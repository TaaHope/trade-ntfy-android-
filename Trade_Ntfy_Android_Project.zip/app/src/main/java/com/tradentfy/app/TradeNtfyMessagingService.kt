package com.tradentfy.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TradeNtfyMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Thread {
            try { ApiClient.registerDevice(token) } catch (_: Exception) { /* MainActivity retries when opened. */ }
        }.start()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "Trade ntfy"
        val body = message.notification?.body ?: message.data["body"] ?: "You have a new notification."
        val topic = message.data["topic"].orEmpty()
        saveInboxItem(title, body, topic)

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingIntent = PendingIntent.getActivity(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), intent, flags)
        val notification = NotificationCompat.Builder(this, "trade_ntfy_general")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true)
            .setContentIntent(pendingIntent).build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun saveInboxItem(title: String, body: String, topic: String) {
        val prefs = getSharedPreferences("trade_ntfy_inbox", MODE_PRIVATE)
        val items = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        items.put(JSONObject().put("title", title).put("body", body).put("topic", topic).put("time", stamp))
        // Keep the latest 200 messages in local storage.
        val trimmed = JSONArray()
        val start = (items.length() - 200).coerceAtLeast(0)
        for (i in start until items.length()) trimmed.put(items.getJSONObject(i))
        prefs.edit().putString("items", trimmed.toString()).apply()
    }
}
