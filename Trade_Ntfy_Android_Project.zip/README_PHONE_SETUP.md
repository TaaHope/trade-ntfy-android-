# Trade ntfy Android project (v1.6 development build)

Trade ntfy is a general-purpose Android client for ntfy-compatible servers. It defaults to `https://ntfy.sh`. Public topics do not require account registration; protected topics use credentials or custom headers configured by the server administrator.

## Included features
- Blue Trade ntfy header and custom logo, with a pale green app background.
- Overflow menu with Settings, send notification, clear history, share and About.
- Add/open/remove topic subscriptions and publish messages to a topic.
- Background JSON streaming with reconnect handling, Android notifications, local history and retention controls.
- Global mute, per-topic mute, minimum priority, urgent repeat alerts, and Android channel sound/vibration settings.
- Download attachment preference with Off / 1 MB / 5 MB / 10 MB limits. The service auto-downloads supported HTTPS attachments only when the server provides a size within the selected limit.
- Manage users: save multiple login profiles for protected topics, select the active login, edit or remove saved profiles. This does not create accounts on the server or change server-side permissions; that remains an administrator task.
- Default server, username/password, custom HTTP headers, connection test, connection protocol option and diagnostic logs.
- Dark mode, message-bar preference, notification retention, and subscription management.
- JSON backup/restore for subscriptions and supported preferences. Passwords and custom headers are intentionally excluded from backups.
- Language preference for System default, English and Shona. Shona currently translates settings section and setting titles; some summaries, dialogs and message text remain in English.

## Build on GitHub from a phone
1. Upload this ZIP to the repository root as `Trade_Ntfy_Android_Project.zip`. Delete older matching ZIPs first so the workflow cannot select stale source.
2. Put the workflow YAML provided in the ChatGPT conversation in `.github/workflows/build.yml`.
3. Open GitHub → Actions → **Build Trade ntfy APK** → **Run workflow**.
4. Download the `Trade-ntfy-APK` artifact from a successful run, extract it, and install `app-debug.apk`.

## Notes
- This ZIP is source code, not a prebuilt APK. A successful GitHub Actions build is still required.
- Android may restrict background activity depending on battery optimisation. Allow background activity for Trade ntfy if messages stop arriving.
- Public topic names are not private. Do not use guessable topic names for sensitive information.
- The connection test checks the ntfy health endpoint. A successful health check does not guarantee permission to publish or subscribe to every topic.
- Login profiles are stored locally on the device. Protect the device and do not share backups containing sensitive information (backups omit saved passwords and custom headers).


## Version 1.6.0 update

- Uses Trade ntfy blue branding with a pale green app canvas and matching pale-green, rounded, logo-branded dialogs.
- Settings use real switches for binary preferences such as alerts, muting, dark mode, attachment downloads, logging, and connection protocol.
- Add Subscription remains a compact popup and includes optional server selection, protected-topic credentials, and an instant-delivery preference with a clear platform-support note.
- The app remains an ntfy-compatible client: user accounts and protected-topic permissions are controlled by the selected server.


## Version 1.6.0 — sound and vibration

- Choose a notification ringtone from Android's system notification sound picker.
- Preview the chosen sound from Settings → Notifications → Test ringtone.
- Independently enable or disable vibration for message notifications.
- Notification sound and vibration preferences are included in JSON backups.
- Android notification channels are created for the selected sound/vibration combination because Android does not allow an existing channel's sound to be changed in place. If Android has an old channel configured, use Settings → Notifications → Channel settings to review it.
