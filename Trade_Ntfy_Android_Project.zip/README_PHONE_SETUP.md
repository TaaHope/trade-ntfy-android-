# Trade ntfy Android project (v1.4)

Trade ntfy is an Android ntfy-compatible topic client. It defaults to `https://ntfy.sh`; it does not require a Trade ntfy account for public topics. Protected topics use the username/password or custom headers configured by the server owner.

## Included
- Add a subscription using the floating `+` button; enter server URL and topic.
- Open a topic to view recent messages, send a message, copy its name, mute/unmute it, or unsubscribe.
- Long-lived JSON streaming with reconnect handling for background subscriptions.
- Android notifications, priority filtering, global mute, per-topic mute, and a local history of up to 200 recent messages.
- Notification history retention (never, 7, 30 or 90 days), clear-history action, and channel sound/vibration controls through Android settings.
- Dedicated Settings screen reachable from the overflow menu, plus app sharing and About actions.
- Blue Trade ntfy header and a pale green background, with the existing app logo retained.
- Default server, username/password, custom headers, connection test, connection protocol timeout preference, diagnostics logging, dark mode and message-bar preference.
- JSON backup/restore of subscriptions and supported preferences. Credentials and custom headers are intentionally not exported because they may contain secrets.

## Build on GitHub from a phone
1. Upload this ZIP to the repository root as `Trade_Ntfy_Android_Project.zip` (replace/delete older `Trade_Ntfy_Android_Project*.zip` files so the workflow cannot select stale source).
2. Put the workflow YAML supplied in the ChatGPT conversation in `.github/workflows/build.yml`.
3. Open GitHub → Actions → **Build Trade ntfy APK** → **Run workflow**.
4. Open the successful run, download the `Trade-ntfy-APK` artifact, extract it, and install `app-debug.apk`.

## Notes
- Android may restrict background activity depending on battery optimisation. Allow background activity for Trade ntfy on the phone if messages stop arriving.
- A server must permit the selected topic and credentials. Public topic names are not private; do not use guessable topics for sensitive information.
- The connection test checks the ntfy health endpoint. A successful health check does not guarantee permission to publish or subscribe to every topic.
- This project ZIP contains Android source, not a prebuilt APK. GitHub Actions must build it.
