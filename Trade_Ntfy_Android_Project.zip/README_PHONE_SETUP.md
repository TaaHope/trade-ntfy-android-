# Trade ntfy — general-purpose notification app

Trade ntfy is an independent, general-purpose topic-based notification app. It supports account sign-in, an on-device inbox, publishing messages to subscribed topics, topic creation/joining, device registration, and Firebase Cloud Messaging delivery.

## Project contents

- `app/`: Android app source, launcher icon, Firebase Authentication and FCM integration.
- `server/app.py`: independent API for authenticated device registration, topics, subscriptions and sending general notifications.
- `server/requirements.txt`: API dependencies.

## 1. Configure Firebase for this app

The Android application ID is `com.tradentfy.app`. The old Firebase configuration was created for a different Android package and must not be reused for this application.

1. Open Firebase Console and select the Firebase project you want Trade ntfy to use, or create a separate Firebase project if you want complete project-level separation.
2. In Project settings, add a new Android app with package name exactly `com.tradentfy.app`.
3. Download the `google-services.json` file for that newly registered Android app.
4. Replace the old `google-services.json` file at the root of the GitHub repository with this new file. The current workflow copies the root file to `app/google-services.json` when building.
5. In Firebase Console > Authentication > Sign-in method, enable **Email/Password**.
6. For the server, create a Firebase Admin SDK service-account JSON and store it privately on the server only. Never commit that private key to GitHub or include it in the Android app.

The public Android `google-services.json` is client configuration, not the Admin SDK private key. However, it should match this app's package and Firebase project.

## 2. Deploy the independent notification API

The app needs a publicly reachable HTTPS API before users on different devices can send and receive messages. This backend is a separate service and does not connect to a trading service.

On a server with Python 3.10+, run these commands from this `server` directory:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:FCM_PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID"
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\SecurePath\firebase-service-account.json"
.\.venv\Scripts\python.exe -m waitress --listen=127.0.0.1:8766 app:app
```

Put the API behind a properly configured HTTPS domain/reverse proxy before connecting phones. Do not expose Flask's development server directly to the internet. Keep the service-account JSON outside the repository and restrict its file permissions.

Test `https://YOUR_HOST/api/health`; it should return JSON containing `"ok": true`.

## 3. Build the APK

1. Upload this project archive using the filename pattern required by your existing GitHub Actions workflow. The archive filename is only for build automation; the app itself is named Trade ntfy.
2. Ensure the new `google-services.json` for `com.tradentfy.app` is present at the repository root.
3. Open Actions, run/check the APK workflow, and download the APK artifact after a successful build.
4. Install the APK and grant notification permission.

## 4. First launch

1. Create an account with an email address and a password of at least six characters.
2. In Settings, enter the deployed backend HTTPS URL and save it.
3. Open Topics and create a topic or join one by its exact name.
4. Open Send, enter a title, message and subscribed topic, then send.
5. Install the app on another device, sign in, subscribe to the same topic, and test delivery.

## API endpoints

- `GET /api/health` — health check.
- `POST /api/device` — register/update the signed-in user's FCM token.
- `GET /api/topics` — list joined topics.
- `POST /api/topics/create` — create and subscribe to a topic.
- `POST /api/topics/join` — subscribe to an existing topic.
- `POST /api/topics/leave` — leave a topic.
- `POST /api/notifications/send` — send a notification to a topic.

All endpoints except health require a Firebase Authentication ID token. The API verifies it server-side. Delivery is subject to Firebase/platform quotas, device connectivity and appropriate abuse protections.

## Before public launch

This archive is source code, not a hosted service or a verified production release. The backend must be deployed and tested. Topic names are joinable by exact name in this initial version; do not use it for confidential channels until access controls are implemented. Add email verification, abuse protections, a privacy policy, data deletion and retention controls, and release signing before public launch.
