# Trade ntfy — general-purpose notification app

Trade ntfy is designed as a general notification inbox and topic-based publisher, not a GoldEA-only app. It supports Firebase email/password accounts, local inbox history, sending to subscribed topics, topic creation/joining, multi-device registration, and FCM delivery. GoldEA can remain one external source; do not replace its existing approval logic with this service.

## What is included

- `app/`: Android app source, branded launcher icon, Firebase Authentication and FCM.
- `server/app.py`: separate Flask API for account-verified device registration, topics and notification sending.
- `server/requirements.txt`: server dependencies.
- `.github/workflows/build-apk.yml`: existing workflow can extract this project archive and build the APK.

## 1. Firebase configuration

1. In Firebase Console, open the same Firebase project used by the installed Trade ntfy app.
2. Keep the Android package name exactly `com.onedge.goldeanotify`.
3. Download the Android `google-services.json` file and keep it in the repository as expected by the workflow; it must be copied to `app/google-services.json` during the build.
4. In Firebase Console > Authentication > Sign-in method, enable **Email/Password**.
5. In Project settings > Service accounts, generate a Firebase Admin SDK service-account JSON for the server only. Never place this private key in the Android app or public GitHub repository.

## 2. Deploy the notification API

The app requires a publicly reachable HTTPS backend. This API is a separate service from the existing GoldEA approval server, so it can be tested without changing `C:\GoldEAApproval\app.py` or the GoldEA EA.

On the server host, install Python 3.10+ and then run from this `server` directory:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:FCM_PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID"
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\SecurePath\firebase-service-account.json"
.\.venv\Scripts\python.exe -m waitress --listen=127.0.0.1:8766 app:app
```

The example binds only to localhost. Put it behind a properly configured HTTPS reverse proxy/domain before using it from phones or publishing the app. Do not expose Flask's development server directly to the internet. Keep the service-account JSON outside the repository and restrict file permissions.

Test the deployed URL in a browser: `https://YOUR_HOST/api/health` should return JSON containing `"ok": true`.

## 3. Build the Android APK

1. Upload this archive's contents as the replacement project ZIP in the GitHub repository, keeping the filename pattern `GoldEA_Notify_Android_Project*.zip` so the workflow can find it.
2. Keep `google-services.json` at the repository root if that is what your current workflow expects; the workflow copies it into `app/`.
3. Run the successful GitHub Actions workflow and download the APK artifact.
4. Install the APK and allow notifications.

## 4. First app launch

1. Create an account with an email address and password (minimum 6 characters).
2. Open Settings and enter the deployed backend HTTPS URL, for example `https://notify.example.com`.
3. Tap Save server URL. The phone's FCM token is registered automatically after sign-in.
4. Open Topics and create a topic, or join an existing topic by its exact name.
5. Open Send, enter a title, message and subscribed topic, then send.
6. Install the app on another device, sign in with an account subscribed to the same topic, and verify delivery.

## API endpoints

- `GET /api/health` — health check.
- `POST /api/device` — register/update the signed-in user's FCM token.
- `GET /api/topics` — list topics the user joined.
- `POST /api/topics/create` — create and subscribe to a topic (`{"name":"team-updates"}`).
- `POST /api/topics/join` — subscribe to an existing topic.
- `POST /api/topics/leave` — leave a topic (topic owner cannot leave their own topic).
- `POST /api/notifications/send` — send to a topic (`{"title":"Notice","body":"Message","topic":"team-updates"}`).

All endpoints except health require a Firebase Authentication ID token. The API verifies it server-side. Messages are delivered to registered devices belonging to topic subscribers. There is no app-defined fixed daily message allowance; actual delivery remains subject to Firebase/platform quotas, device connectivity, and applicable abuse protections.

## Security and limitations

- This is a starting production architecture, not a hosted service by itself. The backend must be deployed and monitored before general users can send/receive across devices.
- Topic names are open to join by exact name in this initial version; do not use this version for confidential channels until invitation/ACL management is added.
- Add email verification, abuse controls, privacy policy, data deletion, retention rules and Play Store signing/release setup before public launch.
- Firebase Android config is client configuration, not the Admin SDK private key. Configure Firebase API restrictions and security controls appropriate to the project.
- Do not change the existing GoldEA approval PIN, API key, database, expiry rules or trade-approval state machine as part of deploying this separate notification API.
