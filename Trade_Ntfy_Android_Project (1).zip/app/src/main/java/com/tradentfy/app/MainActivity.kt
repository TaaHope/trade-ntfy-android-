package com.tradentfy.app

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var selectedTopic: String? = null
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val server: String get() = prefs.getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        showTopics()
        startSubscriber()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) showTopics() }

    private fun topics(): MutableList<String> {
        val arr = try { JSONArray(prefs.getString("topics", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }.distinct().toMutableList()
    }
    private fun saveTopics(items: List<String>) { prefs.edit().putString("topics", JSONArray(items.distinct()).toString()).apply(); startSubscriber() }

    private fun showTopics() {
        selectedTopic = null
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(15), dp(10), dp(15)); setBackgroundColor(Color.rgb(47, 132, 116)) }
        bar.addView(TextView(this).apply { text = "Subscribed topics"; textSize = 23f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        val menu = TextView(this).apply { text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(10), 0, dp(10), 0); setOnClickListener { showOverflow(this) } }
        bar.addView(menu)
        root.addView(bar)
        status = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY); setPadding(dp(16), dp(5), dp(16), dp(5)) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val fabRow = LinearLayout(this).apply { gravity = Gravity.RIGHT; setPadding(dp(14), dp(8), dp(20), dp(20)) }
        fabRow.addView(TextView(this).apply {
            text = "+"; textSize = 36f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(47, 132, 116));
            elevation = dp(5).toFloat(); setOnClickListener { showAddTopicDialog() }
        }, LinearLayout.LayoutParams(dp(64), dp(64)))
        root.addView(fabRow)
        setContentView(root)
        val all = topics()
        if (all.isEmpty()) {
            list.addView(TextView(this).apply { text = "No subscriptions yet.\n\nTap + to add a topic."; textSize = 17f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(dp(28), dp(55), dp(28), dp(55)) })
        } else all.forEach { topic ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(17), dp(14), dp(17)); setOnClickListener { showTopic(topic) } }
            row.addView(TextView(this).apply { text = "▣"; textSize = 30f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; }, LinearLayout.LayoutParams(dp(52), dp(50)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            texts.addView(TextView(this).apply { text = topic; textSize = 17f; setTextColor(Color.rgb(28, 28, 28)) })
            val count = prefs.getInt("count_$topic", 0)
            texts.addView(TextView(this).apply { text = "$count notifications"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(3), 0, 0) })
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 28f; setTextColor(Color.GRAY) })
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(242, 242, 242)) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        status.text = if (all.isEmpty()) "Server: $server" else "${all.size} topic subscription(s) · $server"
    }

    private fun showOverflow(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Settings").setOnMenuItemClickListener { showSettingsDialog(); true }
            menu.add("Rate the app ⭐").setOnMenuItemClickListener { Toast.makeText(this@MainActivity, "Thank you for using Trade ntfy.", Toast.LENGTH_SHORT).show(); true }
            show()
        }
    }

    private fun showAddTopicDialog() {
        val input = EditText(this).apply { hint = "Topic name (e.g. team-updates)"; setSingleLine(true) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0); addView(input) }
        AlertDialog.Builder(this).setTitle("Add subscription topic").setMessage("Enter the exact topic name you want to follow.").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Subscribe") { _, _ ->
                val topic = input.text.toString().trim()
                if (!validTopic(topic)) { toast("Use 1–64 letters, numbers, dots, hyphens or underscores."); return@setPositiveButton }
                val items = topics()
                if (topic !in items) items.add(topic)
                saveTopics(items); showTopics(); toast("Subscribed to $topic")
            }.show()
    }

    private fun showSettingsDialog() {
        val input = EditText(this).apply { hint = "https://ntfy.sh"; setSingleLine(true); setText(server); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0); addView(TextView(this@MainActivity).apply { text = "Notification server URL. Default: https://ntfy.sh"; textSize = 14f }); addView(input) }
        AlertDialog.Builder(this).setTitle("Settings").setView(body).setNegativeButton("Cancel", null).setNeutralButton("Test") { _, _ ->
            val candidate = input.text.toString().trim().trimEnd('/')
            executor.execute { try { val c = URL("$candidate/v1/health").openConnection() as HttpURLConnection; c.connectTimeout = 5000; c.readTimeout = 5000; val code = c.responseCode; runOnUiThread { toast(if (code in 200..299) "Server is reachable." else "Server responded with HTTP $code") }; c.disconnect() } catch (e: Exception) { runOnUiThread { toast("Connection failed: ${e.message}") } } }
        }.setPositiveButton("Save") { _, _ ->
            val candidate = input.text.toString().trim().trimEnd('/')
            if (!candidate.startsWith("https://")) toast("Use an HTTPS server URL.") else { prefs.edit().putString("server", candidate).apply(); startSubscriber(); showTopics() }
        }.show()
    }

    private fun showTopic(topic: String) {
        selectedTopic = topic
        val options = arrayOf("View recent notifications", "Send a notification", "Unsubscribe")
        AlertDialog.Builder(this).setTitle(topic).setItems(options) { _, which ->
            when (which) { 0 -> showTopicMessages(topic); 1 -> showPublishDialog(topic); 2 -> AlertDialog.Builder(this).setTitle("Unsubscribe?").setMessage("Remove $topic from this device?").setNegativeButton("Cancel", null).setPositiveButton("Unsubscribe") { _, _ -> saveTopics(topics().filterNot { it == topic }); showTopics() }.show() }
        }.show()
    }

    private fun showTopicMessages(topic: String) {
        val arr = try { JSONArray(prefs.getString("messages", "[]")) } catch (_: Exception) { JSONArray() }
        val lines = (arr.length() - 1 downTo 0).mapNotNull { i -> arr.optJSONObject(i)?.takeIf { it.optString("topic") == topic }?.let { "${it.optString("title", topic)}\n${it.optString("body")}\n${it.optString("time")} " } }
        AlertDialog.Builder(this).setTitle(topic).setMessage(if (lines.isEmpty()) "No notifications received on this device yet." else lines.take(25).joinToString("\n\n"))
            .setPositiveButton("Send message") { _, _ -> showPublishDialog(topic) }.setNeutralButton("Copy topic") { _, _ -> copy(topic) }.setNegativeButton("Close", null).show()
    }

    private fun showPublishDialog(topic: String) {
        val title = EditText(this).apply { hint = "Title (optional)"; setSingleLine(true) }
        val message = EditText(this).apply { hint = "Message"; minLines = 3; gravity = Gravity.TOP }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0); addView(title); addView(message) }
        AlertDialog.Builder(this).setTitle("Send to $topic").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Publish") { _, _ ->
            val text = message.text.toString().trim()
            if (text.isBlank()) { toast("Enter a message."); return@setPositiveButton }
            executor.execute {
                try {
                    val conn = URL("$server/${encodeTopic(topic)}").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"; conn.connectTimeout = 8000; conn.readTimeout = 8000; conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                    val t = title.text.toString().trim(); if (t.isNotBlank()) conn.setRequestProperty("Title", t)
                    conn.outputStream.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode; conn.disconnect()
                    runOnUiThread { toast(if (code in 200..299) "Notification published to $topic" else "Publish failed (HTTP $code). Check topic/server settings.") }
                } catch (e: Exception) { runOnUiThread { toast("Publish failed: ${e.message}") } }
            }
        }.show()
    }

    private fun startSubscriber() {
        val intent = Intent(this, NtfySubscriptionService::class.java).apply { action = NtfySubscriptionService.ACTION_RESTART }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) { }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("trade_ntfy_messages", "Topic notifications", NotificationManager.IMPORTANCE_HIGH))
            manager.createNotificationChannel(NotificationChannel("trade_ntfy_connection", "Trade ntfy connection", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun validTopic(s: String) = s.matches(Regex("[A-Za-z0-9._-]{1,64}"))
    private fun encodeTopic(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun copy(s: String) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Topic", s)); toast("Topic copied") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
