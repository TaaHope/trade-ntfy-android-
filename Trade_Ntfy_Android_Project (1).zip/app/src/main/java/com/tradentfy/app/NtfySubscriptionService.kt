package com.tradentfy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class NtfySubscriptionService : Service() {
    @Volatile private var running = false
    @Volatile private var generation = 0
    private val active = ConcurrentHashMap<String, Boolean>()
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val server: String get() = prefs.getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')

    override fun onCreate() { super.onCreate(); createChannels(); startForeground(4100, ongoingNotification()) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        restartStreams()
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { running = false; generation++; super.onDestroy() }

    @Synchronized private fun restartStreams() {
        generation++
        val myGeneration = generation
        running = true
        active.clear()
        val topics = try {
            val arr = JSONArray(prefs.getString("topics", "[]"))
            (0 until arr.length()).map { arr.getString(it) }.distinct()
        } catch (_: Exception) { emptyList() }
        topics.forEach { topic ->
            if (active.putIfAbsent(topic, true) == null) thread(name = "ntfy-$topic") { streamTopic(topic, myGeneration) }
        }
    }

    private fun streamTopic(topic: String, gen: Int) {
        while (running && gen == generation) {
            var conn: HttpURLConnection? = null
            try {
                val safeTopic = topic.replace(" ", "%20")
                conn = URL("$server/$safeTopic/json").openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 70000; conn.setRequestProperty("Accept", "application/json")
                val code = conn.responseCode
                if (code !in 200..299) { Thread.sleep(5000); continue }
                conn.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.forEach { line ->
                        if (!running || gen != generation) return@forEach
                        try {
                            val obj = JSONObject(line)
                            if (obj.optString("event") == "message") receive(topic, obj)
                        } catch (_: Exception) { }
                    }
                }
            } catch (_: Exception) { try { Thread.sleep(3000) } catch (_: Exception) { } }
            finally { conn?.disconnect() }
        }
        active.remove(topic)
    }

    private fun receive(topic: String, event: JSONObject) {
        val title = event.optString("title").ifBlank { topic }
        val body = event.optString("message").ifBlank { "New notification" }
        val timestamp = event.optLong("time", System.currentTimeMillis() / 1000) * 1000
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
        synchronized(this) {
            val arr = try { JSONArray(prefs.getString("messages", "[]")) } catch (_: Exception) { JSONArray() }
            arr.put(JSONObject().put("topic", topic).put("title", title).put("body", body).put("time", stamp))
            val trimmed = JSONArray(); for (i in (arr.length() - 200).coerceAtLeast(0) until arr.length()) trimmed.put(arr.getJSONObject(i))
            prefs.edit().putString("messages", trimmed.toString()).putInt("count_$topic", prefs.getInt("count_$topic", 0) + 1).apply()
        }
        val intent = Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP }
        val pi = PendingIntent.getActivity(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = NotificationCompat.Builder(this, "trade_ntfy_messages").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText("[$topic] $body").setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        sendBroadcast(Intent(ACTION_MESSAGE).setPackage(packageName).putExtra("topic", topic))
    }

    private fun ongoingNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 4100, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return NotificationCompat.Builder(this, "trade_ntfy_connection").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Trade ntfy is listening").setContentText("Listening for subscribed topic messages")
            .setContentIntent(pi).setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("trade_ntfy_messages", "Topic notifications", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel("trade_ntfy_connection", "Trade ntfy connection", NotificationManager.IMPORTANCE_LOW))
        }
    }
    companion object {
        const val ACTION_RESTART = "com.tradentfy.app.RESTART_STREAMS"
        const val ACTION_STOP = "com.tradentfy.app.STOP_STREAMS"
        const val ACTION_MESSAGE = "com.tradentfy.app.NEW_MESSAGE"
    }
}
