# Trade ntfy Android project

Trade ntfy is an Android client for the public ntfy-compatible service at **https://ntfy.sh**. It connects directly to the public notification service and does not require an account or a separate application server.

## Features
- Add and remove topic subscriptions from the + button.
- Receive live messages from subscribed topics and show Android notifications.
- Open Settings from the top-right menu to choose the server URL (default: https://ntfy.sh).
- Publish a message to a topic from that topic's menu.
- Locally stores the latest 200 received messages per device.

## Important topic privacy note
Public topics on ntfy.sh are public and guessable topic names are not private. Anyone who knows a topic name may be able to subscribe to messages or publish to it. Do not send passwords, account numbers, private personal data, or trading credentials through public topics. For private topics, use a private ntfy server with authentication and HTTPS.

## Build
The GitHub Actions workflow builds `app/build/outputs/apk/debug/app-debug.apk`. No external project configuration file is required. The package is `com.tradentfy.app`.

## Android background behaviour
The app uses an Android foreground service while subscriptions are active to keep topic streams connected. Android may still restrict background operation under battery-saving policies; allow background activity if notifications are delayed.
