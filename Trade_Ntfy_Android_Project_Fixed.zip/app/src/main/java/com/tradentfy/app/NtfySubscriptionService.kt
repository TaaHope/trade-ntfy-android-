package com.tradentfy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.media.RingtoneManager
import android.media.AudioAttributes
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.DownloadManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class NtfySubscriptionService : Service() {
    @Volatile private var running = false
    @Volatile private var generation = 0
    private val active = ConcurrentHashMap<String, Boolean>()
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val server: String get() = prefs.getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')

    override fun onCreate() { super.onCreate(); createChannels(); startForeground(4100, ongoingNotification()) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        restartStreams()
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { running = false; generation++; super.onDestroy() }

    @Synchronized private fun restartStreams() {
        generation++
        val myGeneration = generation
        running = true
        active.clear()
        val topics = try {
            val arr = JSONArray(prefs.getString("topics", "[]"))
            (0 until arr.length()).map { arr.getString(it) }.distinct()
        } catch (_: Exception) { emptyList() }
        topics.forEach { topic ->
            if (active.putIfAbsent(topic, true) == null) thread(name = "ntfy-$topic") { streamTopic(topic, myGeneration) }
        }
    }

    private fun streamTopic(topic: String, gen: Int) {
        while (running && gen == generation) {
            var conn: HttpURLConnection? = null
            try {
                val safeTopic = topic.replace(" ", "%20")
                conn = URL("$server/$safeTopic/json").openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = if (prefs.getBoolean("json_stream", true)) 70000 else 15000
                conn.setRequestProperty("Accept", "application/json")
                applyHeaders(conn)
                val code = conn.responseCode
                if (code !in 200..299) { Thread.sleep(5000); continue }
                conn.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.forEach { line ->
                        if (!running || gen != generation) return@forEach
                        try {
                            val obj = JSONObject(line)
                            if (obj.optString("event") == "message") receive(topic, obj)
                        } catch (_: Exception) { }
                    }
                }
            } catch (e: Exception) {
                recordDiagnostic("Connection error for $topic: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}")
                try { Thread.sleep(3000) } catch (_: Exception) { }
            } finally { conn?.disconnect() }
        }
        active.remove(topic)
    }

    private fun applyHeaders(c: HttpURLConnection) {
        val username = prefs.getString("username", "") ?: ""
        val password = prefs.getString("password", "") ?: ""
        if (username.isNotBlank()) c.setRequestProperty("Authorization", "Basic " + Base64.encodeToString("$username:$password".toByteArray(), Base64.NO_WRAP))
        prefs.getString("custom_headers", "")?.lineSequence()?.forEach { line ->
            val i = line.indexOf(':')
            if (i > 0) { val key = line.substring(0, i).trim(); val value = line.substring(i + 1).trim(); if (key.isNotBlank()) c.setRequestProperty(key, value) }
        }
    }

    private fun receive(topic: String, event: JSONObject) {
        val title = event.optString("title").ifBlank { topic }
        val body = event.optString("message").ifBlank { "New notification" }
        val timestamp = event.optLong("time", System.currentTimeMillis() / 1000) * 1000
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
        val targetUrl = resolveNotificationTarget(event, body)
        recordDiagnostic("Received message on $topic (priority ${event.optInt("priority", 3)})${if (targetUrl.isNotBlank()) "; click target available" else ""}")
        synchronized(this) {
            val arr = try { JSONArray(prefs.getString("messages", "[]")) } catch (_: Exception) { JSONArray() }
            val saved = JSONObject().put("topic", topic).put("title", title).put("body", body).put("time", stamp)
            if (targetUrl.isNotBlank()) saved.put("target_url", targetUrl)
            val attachment = event.optJSONObject("attachment")
            if (attachment != null) {
                saved.put("attachment_url", attachment.optString("url"))
                saved.put("attachment_name", attachment.optString("name", "attachment"))
                saved.put("attachment_size", attachment.optLong("size", -1L))
            }
            arr.put(saved)
            val trimmed = JSONArray(); for (i in (arr.length() - 500).coerceAtLeast(0) until arr.length()) trimmed.put(arr.getJSONObject(i))
            prefs.edit().putString("messages", trimmed.toString()).putInt("count_$topic", prefs.getInt("count_$topic", 0) + 1).apply()
        }
        val attachment = event.optJSONObject("attachment")
        if (attachment != null && prefs.getBoolean("auto_download_attachments", false)) {
            val attachmentUrl = attachment.optString("url", "")
            val attachmentName = attachment.optString("name", "trade-ntfy-attachment")
            val attachmentSize = attachment.optLong("size", -1L)
            val limitBytes = prefs.getInt("attachment_limit_mb", 1).toLong() * 1024L * 1024L
            if (attachmentUrl.startsWith("https://") && attachmentSize >= 0L && attachmentSize <= limitBytes) {
                try {
                    val request = DownloadManager.Request(Uri.parse(attachmentUrl))
                        .setTitle(attachmentName)
                        .setDescription("Attachment from Trade ntfy · $topic")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    val username = prefs.getString("username", "") ?: ""
                    val password = prefs.getString("password", "") ?: ""
                    if (username.isNotBlank()) request.addRequestHeader("Authorization", "Basic " + Base64.encodeToString("$username:$password".toByteArray(), Base64.NO_WRAP))
                    prefs.getString("custom_headers", "")?.lineSequence()?.forEach { line ->
                        val i = line.indexOf(':')
                        if (i > 0) request.addRequestHeader(line.substring(0, i).trim(), line.substring(i + 1).trim())
                    }
                    getSystemService(Context.DOWNLOAD_SERVICE).let { it as DownloadManager }.enqueue(request)
                    recordDiagnostic("Queued attachment download: $attachmentName")
                } catch (e: Exception) {
                    recordDiagnostic("Attachment download failed: ${e.message ?: "unknown"}")
                }
            } else if (attachmentUrl.isNotBlank()) {
                recordDiagnostic("Attachment not auto-downloaded (missing HTTPS URL or exceeds configured size limit).")
            }
        }
        val retention = prefs.getInt("retention_days", 30)
        if (retention > 0) pruneOldMessages(retention)
        val mutedTopics = try { JSONArray(prefs.getString("muted_topics", "[]")) } catch (_: Exception) { JSONArray() }
        if ((0 until mutedTopics.length()).any { mutedTopics.optString(it) == topic }) return
        if (!prefs.getBoolean("alerts", true) || prefs.getBoolean("muted", false)) return
        val priority = event.optInt("priority", 3)
        if (priority < prefs.getInt("min_priority", 1)) return
        // A supplied click/link URL takes precedence over opening the topic chat.
        // Notifications with an explicit destination open that destination;
        // messages without one open the relevant topic in Trade ntfy.
        val tapIntent = if (targetUrl.isNotBlank()) {
            Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("open_topic", topic)
            }
        }
        val pi = PendingIntent.getActivity(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), tapIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val soundUriString = prefs.getString("notification_sound_uri", "") ?: ""
        val channelId = notificationChannelId(soundUriString, prefs.getBoolean("vibrate_notifications", true))
        ensureMessageChannel(channelId, soundUriString, prefs.getBoolean("vibrate_notifications", true))
        val n = NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText("[$topic] $body").setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pi).setAutoCancel(true).setPriority(when (priority) { 1 -> NotificationCompat.PRIORITY_MIN; 2 -> NotificationCompat.PRIORITY_LOW; 4 -> NotificationCompat.PRIORITY_HIGH; 5 -> NotificationCompat.PRIORITY_MAX; else -> NotificationCompat.PRIORITY_DEFAULT }).build()
        val notificationId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(notificationId, n)
        if (priority >= 5 && prefs.getBoolean("repeat_urgent", false)) {
            thread(name = "urgent-repeat-$notificationId") {
                repeat(3) {
                    try { Thread.sleep(30000) } catch (_: InterruptedException) { return@thread }
                    if (prefs.getBoolean("alerts", true) && !prefs.getBoolean("muted", false) && prefs.getBoolean("repeat_urgent", false)) {
                        notificationManager.notify(notificationId, n)
                    }
                }
            }
        }
        sendBroadcast(Intent(ACTION_MESSAGE).setPackage(packageName).putExtra("topic", topic))
    }


    /** Finds the destination explicitly supplied by the publisher. Only web URLs are opened. */
    private fun resolveNotificationTarget(event: JSONObject, body: String): String {
        val candidates = mutableListOf<String>()
        listOf("click", "url", "link", "click_url", "open_url", "target_url").forEach { key ->
            val value = event.optString(key, "").trim()
            if (value.isNotBlank() && value != "null") candidates.add(value)
        }
        val actions = event.optJSONArray("actions")
        if (actions != null) {
            for (i in 0 until actions.length()) {
                val action = actions.optJSONObject(i) ?: continue
                if (action.optString("action").equals("view", true) || action.optString("action").equals("open", true)) {
                    val value = action.optString("url", "").trim()
                    if (value.isNotBlank()) candidates.add(value)
                }
            }
        }
        // A publisher may include a destination URL directly in the message body.
        Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(body)?.value?.let { candidates.add(it.trimEnd('.', ',', ')', ']', ';')) }
        for (candidate in candidates) {
            try {
                val resolved = if (candidate.startsWith("/")) URL(URL(server), candidate).toString() else candidate
                val uri = Uri.parse(resolved)
                if ((uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()) return resolved
            } catch (_: Exception) { }
        }
        return ""
    }

    private fun recordDiagnostic(message: String) {
        if (!prefs.getBoolean("record_logs", false)) return
        synchronized(this) {
            val previous = prefs.getString("diagnostic_logs", "") ?: ""
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val lines = (previous + "[$stamp] $message\n").lineSequence().filter { it.isNotBlank() }.toList().takeLast(150)
            prefs.edit().putString("diagnostic_logs", lines.joinToString("\n") + "\n").apply()
        }
    }

    private fun pruneOldMessages(days: Int) {
        try {
            val old = JSONArray(prefs.getString("messages", "[]")); val fresh = JSONArray()
            val cutoff = System.currentTimeMillis() - days.toLong() * 86400000L
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            for (i in 0 until old.length()) {
                val item = old.optJSONObject(i) ?: continue
                val millis = try { fmt.parse(item.optString("time"))?.time ?: 0L } catch (_: Exception) { 0L }
                if (millis >= cutoff) fresh.put(item)
            }
            prefs.edit().putString("messages", fresh.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun ongoingNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 4100, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return NotificationCompat.Builder(this, "trade_ntfy_connection").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Trade ntfy is listening").setContentText("Listening for subscribed topic messages")
            .setContentIntent(pi).setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val sound = prefs.getString("notification_sound_uri", "") ?: ""
            ensureMessageChannel(notificationChannelId(sound, prefs.getBoolean("vibrate_notifications", true)), sound, prefs.getBoolean("vibrate_notifications", true))
            nm.createNotificationChannel(NotificationChannel("trade_ntfy_connection", "Trade ntfy connection", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notificationChannelId(sound: String, vibrate: Boolean): String = "trade_ntfy_messages_" + Integer.toHexString((sound + "|" + vibrate).hashCode())

    private fun ensureMessageChannel(id: String, sound: String, vibrate: Boolean) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(id, "Topic notifications", NotificationManager.IMPORTANCE_HIGH)
            val uri = if (sound.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else if (sound == "silent") null else Uri.parse(sound)
            channel.setSound(uri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            channel.enableVibration(vibrate)
            if (vibrate) channel.vibrationPattern = longArrayOf(0, 250, 150, 250)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    companion object {
        const val ACTION_RESTART = "com.tradentfy.app.RESTART_STREAMS"
        const val ACTION_STOP = "com.tradentfy.app.STOP_STREAMS"
        const val ACTION_MESSAGE = "com.tradentfy.app.NEW_MESSAGE"
    }
}
