package com.onedge.goldeanotify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var tokenView: TextView
    private lateinit var statusView: TextView
    private var latestToken = ""
    private var signalId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermission()
        buildScreen()
        handleIntent(intent)
        refreshToken()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            gravity = Gravity.TOP
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "Trade ntfy"; textSize = 28f; setTextColor(0xFF1F6FEB.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Trading alerts delivered through Firebase Cloud Messaging"
            textSize = 16f; setPadding(0, dp(8), 0, dp(20))
        }
        statusView = TextView(this).apply { text = "Checking Firebase registration…"; textSize = 16f }
        val tokenTitle = TextView(this).apply { text = "This phone's FCM registration token"; textSize = 16f }
        tokenView = TextView(this).apply {
            text = "Loading token…"; textSize = 12f; setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(0xFFEFEFEF.toInt())
        }
        val copyButton = Button(this).apply {
            text = "Copy FCM token"
            setOnClickListener {
                if (latestToken.isBlank()) Toast.makeText(this@MainActivity, "Token is not ready yet.", Toast.LENGTH_SHORT).show()
                else {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("GoldEA FCM token", latestToken))
                    Toast.makeText(this@MainActivity, "Token copied. Keep it private.", Toast.LENGTH_LONG).show()
                }
            }
        }
        val refreshButton = Button(this).apply { text = "Refresh token"; setOnClickListener { refreshToken() } }
        val approvalButton = Button(this).apply { text = "Open approval page"; setOnClickListener { openApprovalPage() } }
        val instructions = TextView(this).apply {
            text = "Setup:\n1. Allow notifications when Android asks.\n2. Copy this token to the VPS as FCM_DEVICE_TOKEN.\n3. Keep the VPS service running.\n\nIf Firebase rotates the token, reopen the app and copy the new token. Keep it private."
            textSize = 14f; setPadding(0, dp(20), 0, 0)
        }
        listOf(title, subtitle, statusView, tokenTitle, tokenView, copyButton, refreshButton, approvalButton, instructions).forEach {
            root.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun refreshToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(this) { task ->
            if (!task.isSuccessful) {
                statusView.text = "Firebase registration failed. Check internet and google-services.json."
                tokenView.text = task.exception?.localizedMessage ?: "No token returned."
                return@addOnCompleteListener
            }
            latestToken = task.result.orEmpty()
            tokenView.text = latestToken
            statusView.text = "Firebase registered on this phone. Ensure Android notifications are enabled."
        }
    }

    private fun handleIntent(intent: Intent?) {
        val id = intent?.getStringExtra("signal_id").orEmpty()
        if (id.isNotBlank()) { signalId = id; statusView.text = "Opened from GoldEA alert. Signal ID: $id" }
    }

    private fun openApprovalPage() {
        val base = "http://100.73.56.46:8765/"
        val url = if (signalId.isNotBlank()) "$base?signal_id=${Uri.encode(signalId)}" else base
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("goldea_trading_alerts", "GoldEA trading alerts", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Buy and sell signals awaiting approval"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
