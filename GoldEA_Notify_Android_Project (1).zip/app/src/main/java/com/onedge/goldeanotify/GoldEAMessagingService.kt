package com.onedge.goldeanotify

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class GoldEAMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Reopen the app and copy the token to the VPS if Firebase rotates it.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        val signalId = data["signal_id"].orEmpty()
        val account = data["account"].orEmpty()
        val symbol = data["symbol"].orEmpty()
        val side = data["side"].orEmpty()
        val title = message.notification?.title ?: "GoldEA — Approval Required"
        val body = message.notification?.body
            ?: listOf(account, symbol, side.replaceFirstChar { it.uppercase() }, "Pending Approval")
                .filter { it.isNotBlank() }.joinToString(", ")

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("signal_id", signalId)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingIntent = PendingIntent.getActivity(this, signalId.hashCode(), intent, flags)
        val notification = NotificationCompat.Builder(this, "goldea_trading_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(pendingIntent).build()
        getSystemService(NotificationManager::class.java)
            .notify(if (signalId.isBlank()) System.currentTimeMillis().toInt() else signalId.hashCode(), notification)
    }
}
