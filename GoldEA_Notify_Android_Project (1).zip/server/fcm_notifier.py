"""FCM sender helper. This does not replace app.py or its approval state machine."""
import os
import os.path
import firebase_admin
from firebase_admin import credentials, messaging

_app = None

def _get_firebase_app():
    global _app
    if _app is not None:
        return _app
    project_id = os.environ.get("FCM_PROJECT_ID", "").strip()
    credential_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
    if not project_id:
        raise RuntimeError("FCM_PROJECT_ID environment variable is missing.")
    if not credential_path:
        raise RuntimeError("GOOGLE_APPLICATION_CREDENTIALS environment variable is missing.")
    if not os.path.isfile(credential_path):
        raise RuntimeError(f"Firebase service-account file not found: {credential_path}")
    try:
        _app = firebase_admin.get_app()
    except ValueError:
        _app = firebase_admin.initialize_app(credentials.Certificate(credential_path), {"projectId": project_id})
    return _app

def send_gold_ea_notification(signal_id, account, symbol, side):
    token = os.environ.get("FCM_DEVICE_TOKEN", "").strip()
    if not token:
        raise RuntimeError("FCM_DEVICE_TOKEN environment variable is missing.")
    account, symbol, side = str(account or "GoldEA"), str(symbol or "Unknown symbol"), str(side or "Signal")
    message = messaging.Message(
        notification=messaging.Notification(
            title="GoldEA — Approval Required",
            body=f"{account}, {symbol}, {side.title()} Pending Approval",
        ),
        data={"signal_id": str(signal_id), "account": account, "symbol": symbol, "side": side},
        android=messaging.AndroidConfig(
            priority="high",
            notification=messaging.AndroidNotification(channel_id="goldea_trading_alerts", sound="default"),
        ),
        token=token,
    )
    return messaging.send(message, app=_get_firebase_app())
