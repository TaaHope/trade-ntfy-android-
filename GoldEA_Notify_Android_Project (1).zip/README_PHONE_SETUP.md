# Trade ntfy — phone-only build

This project is built on GitHub Actions in the cloud, so Android Studio is not needed on your phone.

## Firebase setup
1. Open https://console.firebase.google.com/ on your phone and create a project named `Trade-ntfy`.
2. Add an Android app with package name exactly `com.onedge.goldeanotify`.
3. Download `google-services.json`. Do not rename it.
4. Do not confuse this Android configuration file with the server service-account key.

## GitHub setup
1. Create a GitHub repository named `trade-ntfy-android`.
2. Upload every file/folder from this project ZIP preserving the folder structure.
3. Upload `google-services.json` into the repository's `app/` folder.
4. Commit to `main`, then open Actions and wait for `Build Trade ntfy APK` to finish.
5. Open the successful run and download the `Trade-ntfy-debug` artifact.
6. Extract the downloaded ZIP and install `app-debug.apk`. Allow installation from the browser/file manager if Android asks.
7. Open the app and allow notifications.

## VPS configuration (do not switch Flask yet)
1. In Firebase Console > Project settings > Service accounts, generate a private key JSON.
2. Transfer it securely to `C:\GoldEAApproval\firebase-service-account.json` on the VPS. Never upload this private key to GitHub or the app.
3. Install the sender dependency:
   `& "$env:LOCALAPPDATA\Programs\Python\Python315\python.exe" -m pip install firebase-admin`
4. Open Trade ntfy and copy its FCM token.
5. In the PowerShell window used to start Flask, set:
   `$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\GoldEAApproval\firebase-service-account.json"`
   `$env:FCM_PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID"`
   `$env:FCM_DEVICE_TOKEN = "PASTE_TOKEN_FROM_PHONE"`
6. Keep the existing `GOLDEA_API_KEY`, `NTFY_TOPIC`, app.py, database and EA unchanged at this stage.

`server/fcm_notifier.py` is a helper, not a replacement for app.py. It must be integrated narrowly into the existing notification function after the APK and credentials are verified. Preserve the existing SQLite state transitions and timeout behavior.
