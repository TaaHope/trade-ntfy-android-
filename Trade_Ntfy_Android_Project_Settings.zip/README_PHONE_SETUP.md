# Trade ntfy Android app

Trade ntfy is an ntfy-compatible Android client. It does not require Firebase sign-in, a Firebase service account, or a separate Flask backend.

## Build from GitHub Actions
1. Keep this ZIP in the repository root with a filename beginning `Trade_Ntfy_Android_Project`.
2. Keep the workflow at `.github/workflows/build.yml`.
3. Commit or upload the ZIP. GitHub Actions builds a debug APK and attaches it as the `Trade-ntfy-APK` artifact.
4. Download the artifact ZIP, extract it on the phone, and install the APK.

## Use the app
- Tap `+` to add a subscription.
- Enter a server such as `https://ntfy.sh` and a topic name.
- Tap the topic to view locally saved messages.
- Tap the top-right three-dot menu for Settings, Send notification, Inbox/history, and About.
- Settings includes default server, notification alerts, appearance, backup, and connection information.
- Long-press a topic to open, copy, or unsubscribe.

## Important behaviour
- This version connects to ntfy's JSON streaming endpoint while the app is running. It is a first client implementation, not a complete replacement for ntfy's background delivery infrastructure. Reliable background delivery when Android stops the app still needs a persistent notification/foreground connection or a push relay.
- Public topics are not private. Anyone who knows a public topic name may be able to subscribe or publish according to that server's policy. Use an access-controlled server/topic for sensitive messages.
- Publishing may be disabled by some servers or require authentication.
