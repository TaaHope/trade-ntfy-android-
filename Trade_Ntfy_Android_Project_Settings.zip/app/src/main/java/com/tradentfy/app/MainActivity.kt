package com.tradentfy.app

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val io = Executors.newCachedThreadPool()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val streams = ConcurrentHashMap<String, Boolean>()
    private val prefs by lazy { getSharedPreferences("trade_ntfy", MODE_PRIVATE) }
    private val accent = Color.rgb(49, 92, 255) // Trade ntfy cobalt blue; distinct from ntfy green

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        showTopics()
        startAllStreams()
    }

    override fun onDestroy() { streams.clear(); super.onDestroy() }

    private fun buildPage(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,255)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(12), dp(8), dp(12)); setBackgroundColor(accent) }
        bar.addView(TextView(this).apply { text = title; textSize = 22f; setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        val menu = TextView(this).apply { text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12),0,dp(12),0); setOnClickListener { showMenu(this) } }
        bar.addView(menu)
        root.addView(bar)
        if (subtitle != null) root.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(dp(18), dp(8), dp(18), dp(8)) })
        status = TextView(this).apply { textSize = 13f; setTextColor(accent); setPadding(dp(18), dp(4), dp(18), dp(4)) }
        root.addView(status)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(18)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showTopics() {
        buildPage("Subscribed topics", "Server: ${server()}")
        val topics = topicArray()
        if (topics.length() == 0) {
            content.addView(TextView(this).apply { text = "\nNo subscriptions yet.\n\nTap + to add a topic."; textSize = 19f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(dp(20), dp(55), dp(20), dp(55)) })
        } else for (i in 0 until topics.length()) {
            val t = topics.optJSONObject(i) ?: continue
            val name = t.optString("topic")
            val srv = t.optString("server", server())
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(12), dp(8), dp(12)); setBackgroundColor(Color.WHITE) }
            row.addView(TextView(this).apply { text = "▣"; textSize = 27f; setTextColor(Color.GRAY); setPadding(0,0,dp(12),0) })
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0,-2,1f) }
            texts.addView(TextView(this).apply { text = name; textSize = 17f; setTextColor(Color.BLACK) })
            texts.addView(TextView(this).apply { text = "$srv  •  ${countFor(name)} notifications"; textSize = 12f; setTextColor(Color.DKGRAY) })
            row.addView(texts)
            row.setOnClickListener { showTopicMessages(srv, name) }
            row.setOnLongClickListener { AlertDialog.Builder(this).setTitle(name).setItems(arrayOf("Open messages", "Copy topic", "Unsubscribe")) { _, which -> when(which) { 0 -> showTopicMessages(srv,name); 1 -> copy(name); 2 -> removeTopic(srv,name) } }.show(); true }
            content.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(6) })
        }
        val spacer = Space(this); content.addView(spacer, LinearLayout.LayoutParams(-1,0,1f))
        val add = Button(this).apply { text = "+"; textSize = 30f; setTextColor(Color.WHITE); setBackgroundColor(accent); contentDescription = "Add subscription topic"; setOnClickListener { addSubscriptionDialog() } }
        val holder = FrameLayoutCompat(this).apply { addView(add, android.widget.FrameLayout.LayoutParams(dp(64),dp(64),Gravity.END or Gravity.BOTTOM).apply { setMargins(0,0,dp(8),dp(8)) }) }
        root.addView(holder, LinearLayout.LayoutParams(-1, dp(78)))
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Settings")
        popup.menu.add("Send notification")
        popup.menu.add("Inbox / history")
        popup.menu.add("About Trade ntfy")
        popup.setOnMenuItemClickListener { item -> when(item.title.toString()) {
            "Settings" -> showSettings()
            "Send notification" -> sendDialog()
            "Inbox / history" -> showHistory()
            else -> AlertDialog.Builder(this).setTitle("Trade ntfy").setMessage("A general-purpose ntfy-compatible notification client. Add a server and topic to subscribe.").setPositiveButton("OK",null).show()
        }; true }
        popup.show()
    }

    private fun addSubscriptionDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0) }
        val srv = EditText(this).apply { hint = "Server URL"; setSingleLine(true); setText(server()) }
        val topic = EditText(this).apply { hint = "Subscription topic"; setSingleLine(true) }
        panel.addView(srv); panel.addView(topic)
        AlertDialog.Builder(this).setTitle("Add subscription").setMessage("Enter the notification server and topic name.").setView(panel)
            .setNegativeButton("Cancel",null).setPositiveButton("Subscribe",null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val cleanServer = srv.text.toString().trim().trimEnd('/')
                    val cleanTopic = topic.text.toString().trim()
                    if (!(cleanServer.startsWith("https://") || cleanServer.startsWith("http://"))) { srv.error = "Enter a server URL"; return@setOnClickListener }
                    if (!cleanTopic.matches(Regex("[A-Za-z0-9_-]{1,64}"))) { topic.error = "Use letters, numbers, _ or -"; return@setOnClickListener }
                    val arr = topicArray(); val exists = (0 until arr.length()).any { arr.optJSONObject(it)?.optString("server") == cleanServer && arr.optJSONObject(it)?.optString("topic") == cleanTopic }
                    if (!exists) { arr.put(JSONObject().put("server",cleanServer).put("topic",cleanTopic)); prefs.edit().putString("topics",arr.toString()).putString("server",cleanServer).apply() }
                    dialog.dismiss(); showTopics(); startStream(cleanServer,cleanTopic)
                } }
                dialog.show()
            }
    }

    private fun showSettings() {
        buildPage("Settings")
        section("General", "Default server", "Server used when adding a subscription") {
            val field = EditText(this).apply { setSingleLine(true); setText(server()); hint = "https://ntfy.sh" }
            AlertDialog.Builder(this).setTitle("Default server").setMessage("Enter your preferred ntfy-compatible server URL.").setView(field)
                .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ ->
                    val v = field.text.toString().trim().trimEnd('/'); if (v.startsWith("https://") || v.startsWith("http://")) { prefs.edit().putString("server",v).apply(); showSettings() } else toast("Enter a valid server URL.")
                }.show()
        }
        section("Notifications", "Notification alerts", "Show Android notifications for incoming messages") {
            val enabled = prefs.getBoolean("alerts",true)
            AlertDialog.Builder(this).setTitle("Notification alerts").setMessage("Incoming messages: ${if(enabled) "alerts enabled" else "alerts disabled"}")
                .setNegativeButton("Cancel",null).setPositiveButton(if(enabled) "Turn off" else "Turn on") { _,_ -> prefs.edit().putBoolean("alerts",!enabled).apply(); showSettings() }.show()
        }
        section("Appearance", "Dark mode", "Use a dark background for the app") {
            val dark = prefs.getBoolean("dark",false)
            AlertDialog.Builder(this).setTitle("Dark mode").setMessage("Dark mode is ${if(dark) "on" else "off"}.")
                .setNegativeButton("Cancel",null).setPositiveButton(if(dark) "Turn off" else "Turn on") { _,_ -> prefs.edit().putBoolean("dark",!dark).apply(); showSettings() }.show()
        }
        section("Backup & Restore", "Back up subscriptions", "Export your server and topic list to a text file") { backupTopics() }
        section("Advanced", "Connection protocol", "Uses ntfy JSON streaming over HTTPS") { AlertDialog.Builder(this).setTitle("Connection protocol").setMessage("Trade ntfy connects to each subscribed topic using the ntfy JSON stream. HTTPS is recommended.").setPositiveButton("OK",null).show() }
        content.addView(button("Manage subscriptions") { showTopics() })
        content.addView(button("Clear notification history") { prefs.edit().putString("history","[]").apply(); toast("History cleared.") })
    }

    private fun section(group: String, title: String, desc: String, action: () -> Unit) {
        content.addView(TextView(this).apply { text = group; textSize = 14f; setTextColor(accent); setPadding(dp(6),dp(15),0,dp(8)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); setBackgroundColor(Color.WHITE); setOnClickListener { action() } }
        row.addView(TextView(this).apply { text=title; textSize=17f; setTextColor(Color.BLACK) })
        row.addView(TextView(this).apply { text=desc; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,dp(4),0,0) })
        content.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(5) })
    }

    private fun sendDialog() {
        val panel = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0) }
        val srv = EditText(this).apply { hint="Server URL"; setSingleLine(true); setText(server()) }
        val topic = EditText(this).apply { hint="Topic"; setSingleLine(true) }
        val title = EditText(this).apply { hint="Title (optional)"; setSingleLine(true) }
        val msg = EditText(this).apply { hint="Message"; minLines=3; gravity=Gravity.TOP }
        panel.addView(srv); panel.addView(topic); panel.addView(title); panel.addView(msg)
        AlertDialog.Builder(this).setTitle("Send notification").setView(panel).setNegativeButton("Cancel",null).setPositiveButton("Send",null).create().also { d ->
            d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val s=srv.text.toString().trim().trimEnd('/'); val t=topic.text.toString().trim(); val m=msg.text.toString().trim()
                if (t.isBlank() || m.isBlank()) { toast("Enter a topic and message."); return@setOnClickListener }
                io.execute { try { val c=URL("$s/$t").openConnection() as HttpURLConnection; c.requestMethod="POST"; c.doOutput=true; c.setRequestProperty("Content-Type","text/plain; charset=utf-8"); if(title.text.isNotBlank()) c.setRequestProperty("Title",title.text.toString()); c.outputStream.use { it.write(m.toByteArray(Charsets.UTF_8)) }; val code=c.responseCode; c.disconnect(); runOnUiThread { if(code in 200..299) { toast("Notification sent."); d.dismiss() } else toast("Server returned HTTP $code") } } catch(e:Exception) { runOnUiThread { toast("Send failed: ${e.message}") } } }
            } }; d.show()
        }
    }

    private fun showTopicMessages(srv:String, topic:String) {
        buildPage(topic, srv)
        val hist=historyArray(); val found=(0 until hist.length()).mapNotNull { hist.optJSONObject(it) }.filter { it.optString("server")==srv && it.optString("topic")==topic }.reversed()
        if(found.isEmpty()) content.addView(TextView(this).apply { text="No messages saved for this topic yet."; textSize=17f; setPadding(dp(12),dp(20),dp(12),dp(20)); setTextColor(Color.DKGRAY) })
        found.forEach { item -> content.addView(card(item.optString("title",topic),item.optString("message")+"\n\n"+item.optString("time"))) }
        content.addView(button("Back to subscriptions") { showTopics() })
    }
    private fun showHistory() {
        buildPage("Notification history")
        val a=historyArray(); if(a.length()==0) content.addView(TextView(this).apply { text="No notifications received yet."; textSize=18f })
        for(i in a.length()-1 downTo 0) { val x=a.optJSONObject(i)?:continue; content.addView(card(x.optString("title",x.optString("topic")),x.optString("message")+"\n"+x.optString("topic")+" • "+x.optString("time"))) }
        content.addView(button("Back to subscriptions") { showTopics() })
    }

    private fun startAllStreams() { val a=topicArray(); for(i in 0 until a.length()) { val t=a.optJSONObject(i)?:continue; startStream(t.optString("server",server()),t.optString("topic")) } }
    private fun startStream(srv:String, topic:String) {
        val key="$srv/$topic"; if(streams.putIfAbsent(key,true)!=null) return
        io.execute {
            while(streams[key]==true) {
                var c:HttpURLConnection?=null
                try {
                    c=URL("$srv/$topic/json?since=30m").openConnection() as HttpURLConnection
                    c.connectTimeout=15000; c.readTimeout=0; c.setRequestProperty("Accept","application/json")
                    if(c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
                    c.inputStream.bufferedReader().useLines { lines -> lines.forEach { line -> if(streams[key]!=true) return@forEach; try { val x=JSONObject(line); if(x.optString("event")=="message") receive(srv,topic,x) } catch(_:Exception){} } }
                } catch(_:Exception) { try { Thread.sleep(5000) } catch(_:InterruptedException) { } }
                finally { c?.disconnect() }
            }
            streams.remove(key)
        }
    }
    private fun receive(srv:String, topic:String, x:JSONObject) {
        val message=x.optString("message"); if(message.isBlank()) return
        val title=x.optString("title").ifBlank { topic }
        val time=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date())
        synchronized(this) { val a=historyArray(); a.put(JSONObject().put("server",srv).put("topic",topic).put("title",title).put("message",message).put("time",time)); while(a.length()>300) { val b=JSONArray(); for(i in 1 until a.length()) b.put(a.get(i)); prefs.edit().putString("history",b.toString()).apply(); return@synchronized }; prefs.edit().putString("history",a.toString()).apply() }
        if(prefs.getBoolean("alerts",true)) { val n=androidx.core.app.NotificationCompat.Builder(this,"trade_ntfy_messages").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(message)).setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build(); getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),n) }
    }
    private fun backupTopics() { val out=topicArray().toString(2); val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("Trade ntfy subscriptions",out)); toast("Subscription backup copied to clipboard.") }
    private fun removeTopic(srv:String,topic:String) { val a=topicArray(); val b=JSONArray(); for(i in 0 until a.length()) { val t=a.optJSONObject(i)?:continue; if(!(t.optString("server")==srv && t.optString("topic")==topic)) b.put(t) }; prefs.edit().putString("topics",b.toString()).apply(); streams.remove("$srv/$topic"); showTopics() }
    private fun topicArray()=try { JSONArray(prefs.getString("topics","[]")) } catch(_:Exception){JSONArray()}
    private fun historyArray()=try { JSONArray(prefs.getString("history","[]")) } catch(_:Exception){JSONArray()}
    private fun server()=prefs.getString("server","https://ntfy.sh") ?: "https://ntfy.sh"
    private fun countFor(topic:String)=(0 until historyArray().length()).count { historyArray().optJSONObject(it)?.optString("topic")==topic }
    private fun copy(value:String) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("topic",value)); toast("Topic copied.") }
    private fun button(label:String, action:()->Unit)=Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() }; layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) } }
    private fun card(title:String, body:String)=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); setBackgroundColor(Color.WHITE); addView(TextView(this@MainActivity).apply { text=title; textSize=17f; setTextColor(Color.BLACK) }); addView(TextView(this@MainActivity).apply { text=body; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,dp(5),0,0) }); layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(7) } }
    private fun createNotificationChannel() { if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("trade_ntfy_messages","Trade ntfy messages",NotificationManager.IMPORTANCE_HIGH)) }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
}

private class FrameLayoutCompat(context: Context) : android.widget.FrameLayout(context)
